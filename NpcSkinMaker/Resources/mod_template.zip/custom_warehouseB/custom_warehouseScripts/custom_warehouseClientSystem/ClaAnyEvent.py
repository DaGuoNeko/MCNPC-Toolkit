# -*- coding: utf-8 -*-
import mod.client.extraClientApi as clientApi

ClientSystem = clientApi.GetClientSystemCls()
CF = clientApi.GetEngineCompFactory()
LevelID = clientApi.GetLevelId()
ME = clientApi.GetMinecraftEnum()


class ClaAnyEvent(object):

    def __init__(self, cla_system):
        self.Playerid = clientApi.GetLocalPlayerId()
        self._Mcla = cla_system
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""

    def AnyEvent(self, args):
        back = args.get('back', None)
        data = args['data']
        backdata = getattr(self, data['lx'])(data)
        if back:
            self._Mcla.NotifyToServer('AnyEvent', {'back': back, 'backdata': backdata})
            
