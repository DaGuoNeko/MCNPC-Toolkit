# -*- coding: utf-8 -*-
"""帮助/说明界面 ScreenNode 模板（可选）"""

import mod.client.extraClientApi as clientApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
ScreenNode = clientApi.GetScreenNodeCls()
CF = clientApi.GetEngineCompFactory()


class ModName_help_screen(ScreenNode):

    def __init__(self, namespace, name, param):
        super(ModName_help_screen, self).__init__(namespace, name, param)
        self.mclienSystem = param["cs"]
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        self.Playerid = clientApi.GetLocalPlayerId()
        self.base_paths = "/variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel"

        self.panel_0 = self.base_paths + '/stack_panel/down_panel/panel_0'
        self.panel_1 = self.base_paths + '/stack_panel/down_panel/panel_1'
        self.M_scroll_view = self.panel_0 + '/M_scroll_view'
        self.scroll_view_path = ''
        self.index = param.get('index', 0)

    def Update(self):
        pass

    def Create(self):
        self.scroll_view_path = (
            "/scroll_mouse/scroll_view/stack_panel/background_and_viewport/scrolling_view_port/scrolling_content"
            if not self.GetChildrenName(self.M_scroll_view).count('scroll_touch')
            else "/scroll_touch/scroll_view/panel/background_and_viewport/scrolling_view_port/scrolling_content"
        )
        self._selpanel(self.index, True)

    def Init(self):
        pass

    def _selpanel(self, index, isinit=False):
        if isinit:
            self.GetBaseUIControl(
                self.panel_0 + '/M_scroll_view' + self.scroll_view_path
                + '/stack_panel/tg%d/M_toggle' % index
            ).asSwitchToggle().SetToggleState(True)
        if self.index != index:
            self.GetBaseUIControl(
                self.panel_1 + '/M_scroll_view' + self.scroll_view_path
                + '/nr%d' % self.index
            ).SetVisible(False)
        self.GetBaseUIControl(
            self.panel_1 + '/M_scroll_view' + self.scroll_view_path
            + '/nr%d' % index
        ).SetVisible(True)
        self.index = index

    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#xxx_btn')
    def xxx_btn(self, args):
        clientApi.PopScreen()

    @ViewBinder.binding(ViewBinder.ToggleFilter | ViewBinder.BF_ToggleChanged, '#help_gn_toggle_jh')
    def help_gn_toggle_jh(self, args):
        self._selpanel(args['index'])
