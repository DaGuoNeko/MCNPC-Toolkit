# -*- coding: utf-8 -*-
"""HUD 常驻界面 ScreenNode 模板（可选注入）

设计要点：
- isHud=1 常驻屏幕，不阻挡游戏操作（absorbs_input=false）
- 集成 MoveBtnMappings 实现可拖拽按钮（与 utils.MoveBtnMappings 搭配）
- 提供 GameRenderTickEvent 渲染骨架，配合 miao_lid.get_task_icon_screen_pos
  可实现屏幕外目标追踪箭头
- Update() 每帧回调，适合放定时刷新逻辑

占位命名规则：
- 类名: ModName_hud_screen（生成后替换为实际 Mod 名）
- 注册路径: ModName_hud_screen.main
- 参数传入: {"isHud": 1, "cs": self} 接收 ClientSystem 实例（self.mclienSystem）
"""

import mod.client.extraClientApi as clientApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG
from custom_warehouseScripts.custom_warehouseClientSystem.utils import MoveBtnMappings

ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
ScreenNode = clientApi.GetScreenNodeCls()
CF = clientApi.GetEngineCompFactory()
LevelID = clientApi.GetLevelId()

# 摄像机组件，用于 get_task_icon_screen_pos 箭头算法
compCamera = CF.CreateCamera(LevelID)
compGame = CF.CreateGame(LevelID)


class ModName_hud_screen(ScreenNode):

    def __init__(self, namespace, name, param):
        super(ModName_hud_screen, self).__init__(namespace, name, param)
        self.mclienSystem = param["cs"]
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        self.Playerid = clientApi.GetLocalPlayerId()
        self.base_paths = "/variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel"

        # 可拖拽按钮管理器（Create 中初始化）
        self.MoveBtnMappings = None
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.utils.MoveBtnMappings | None"""

        # HUD 信息文本面板路径
        self.info_text_path = self.base_paths + '/hud_root/info_panel/info_text'

        # 屏幕外追踪箭头图标层（配合 get_task_icon_screen_pos 使用）
        self.arrow_img_path = self.base_paths + '/hud_root/arrow_panel/arrow_img'
        self.arrow_text_path = self.base_paths + '/hud_root/arrow_panel/arrow_text'

        # 追踪目标列表：每项 {'target_pos': (x,y,z), 'state': bool, ...}
        # 填入坐标后，SetArrowPos 会自动计算屏幕位置并显示箭头
        self.tracking_targets = []

        # 等待玩家加载完成
        self.LoadPlayer = False
        self.tick = 0

    # =========================== 生命周期 ===========================

    def Update(self):
        """每帧回调（引擎驱动）。适合放低频刷新逻辑，高频用 GameRenderTickEvent。"""
        self.tick += 1
        # 每 5 帧刷新一次信息文本，避免每帧刷新性能浪费
        if self.tick % 5 == 0:
            self._refresh_info_text()
            self.tick = 0

    def GameRenderTickEvent(self):
        """渲染帧回调。配合 get_task_icon_screen_pos 计算箭头位置。
        仅在玩家加载完成后执行。"""
        if self.LoadPlayer:
            self._update_arrow_pos()

    def Create(self):
        """UI 创建完成回调。初始化可拖拽按钮。"""
        # 2s 后标记玩家加载完成（等待世界渲染就绪）
        CF.CreateGame(LevelID).AddTimer(2.0, self.OnLoad)

        # 初始化可拖拽按钮（与 utils.MoveBtnMappings 搭配）
        # 格式: [按钮路径, 要移动的父面板路径, (偏移x, 偏移y), 按钮回调函数]
        self.MoveBtnMappings = MoveBtnMappings(self, 'ModName_HudMoveData', [
            [self.base_paths + '/hud_root/open_btn_panel/open_btn',
             self.base_paths + '/hud_root/open_btn_panel',
             (-12, -12),
             self.OnOpenBtnClick]
        ])

    def OnLoad(self):
        """玩家加载完成标记"""
        self.LoadPlayer = True

    def Init(self):
        pass

    # =========================== 按钮回调 ===========================

    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#hud_open_btn')
    def OnOpenBtnClick(self, args):
        """可拖拽的打开主界面按钮。带操作 CD 防高频点击。"""
        if self.mclienSystem.AddUserUiCd('hud_open_main', 0.5):
            self.mclienSystem.ToPlayerMsg('请勿高频点击!')
            return
        # 打开用户主界面（取消注释后生效）
        # self.mclienSystem.Open_ModName_user_screen()

    # =========================== 信息文本刷新 ===========================

    def _refresh_info_text(self):
        """刷新 HUD 信息文本。示例：显示玩家坐标。"""
        if not self.LoadPlayer:
            return
        # 示例：显示玩家实时坐标
        pos = compCamera.GetPosition()
        text = '§aX: §f%d  §aY: §f%d  §aZ: §f%d' % (int(pos[0]), int(pos[1]), int(pos[2]))
        self.GetBaseUIControl(self.info_text_path).asLabel().SetText(text)

    # =========================== 屏幕外追踪箭头 ===========================

    def _update_arrow_pos(self):
        """使用 miao_lid.get_task_icon_screen_pos 计算箭头屏幕位置。

        用法：
        1. 向 self.tracking_targets 添加 {'target_pos': (x,y,z), 'state': True}
        2. 本方法每渲染帧计算箭头应在的屏幕坐标并更新 UI
        3. 目标在视野内时箭头贴在准心附近，在视野外时贴在屏幕边缘指向目标
        """
        if not self.tracking_targets:
            return
        # 取第一个激活的追踪目标
        target = None
        for t in self.tracking_targets:
            if t.get('state', False):
                target = t
                break
        if not target:
            return

        player_pos = compCamera.GetPosition()
        pitch, yaw, roll = compCamera.GetCameraRotation()
        screen_size = compGame.GetScreenSize()

        # 调用 miao_lid 的箭头算法
        screen_x, screen_y, rotate_angle, in_center = M.get_task_icon_screen_pos(
            player_pos, yaw, pitch, target['target_pos'], screen_size
        )

        # 更新箭头图标位置和旋转
        arrow_ctrl = self.GetBaseUIControl(self.arrow_img_path)
        arrow_ctrl.SetPosition((screen_x, screen_y))
        arrow_ctrl.asImage().Rotate(rotate_angle)

        # 显示距离
        dist = round(M.GetABposDac(target['target_pos'], player_pos), 1)
        if dist <= 15:
            self.GetBaseUIControl(self.arrow_text_path).asLabel().SetText('')
        else:
            self.GetBaseUIControl(self.arrow_text_path).asLabel().SetText('§e%sm' % dist)

    # =========================== 外部调用接口 ===========================

    def AddTrackingTarget(self, target_pos):
        """添加追踪目标坐标。target_pos: (x, y, z) 世界坐标"""
        self.tracking_targets.append({
            'target_pos': target_pos,
            'state': True
        })

    def ClearTrackingTargets(self):
        """清空所有追踪目标"""
        self.tracking_targets = []

    def PopTipsItem(self, title='', subtitle=''):
        """弹出 HUD 右侧提示消息（简化版，无图标）。
        title: 标题文本, subtitle: 副标题文本"""
        import uuid
        ui_uid = uuid.uuid4().hex[:6]
        stack_path = self.base_paths + '/hud_root/tips_panel/stack_panel'
        self.CreateChildControl('ModName_hud_screen.tips_item', ui_uid,
                                self.GetBaseUIControl(stack_path))
        title_path = stack_path + '/%s/panel/title' % ui_uid
        sub_path = stack_path + '/%s/panel/subtitle' % ui_uid
        self.GetBaseUIControl(title_path).asLabel().SetText(title)
        self.GetBaseUIControl(sub_path).asLabel().SetText(subtitle)
