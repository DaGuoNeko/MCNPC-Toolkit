# -*- coding: utf-8 -*-
"""设置界面 ScreenNode 模板（可选注入）

功能：
- 左右分栏布局：左侧 toggle 切换分类，右侧显示对应设置面板
- 示例控件：toggle 开关、edit_box 文本输入（均双向绑定）
- 关闭时自动保存数据
- 数据读写示例：通过 self.mclienSystem 访问客户端系统

扩展方式：
1. 在 UI JSON 中新增 nrN 面板 + 左侧 toggle 项
2. 在本文件中添加对应的 @ViewBinder.binding 绑定方法
3. 数据存取通过 self.mclienSystem.xxx 访问客户端系统

占位命名规则：
- 类名: ModName_setting_screen（生成后替换为实际 Mod 名）
- 注册路径: ModName_setting_screen.main
- 参数传入: {"cs": self} 接收 ClientSystem 实例（self.mclienSystem）
"""

import mod.client.extraClientApi as clientApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
ScreenNode = clientApi.GetScreenNodeCls()
CF = clientApi.GetEngineCompFactory()
LevelID = clientApi.GetLevelId()


class ModName_setting_screen(ScreenNode):

    def __init__(self, namespace, name, param):
        super(ModName_setting_screen, self).__init__(namespace, name, param)
        self.mclienSystem = param["cs"]
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        self.Playerid = clientApi.GetLocalPlayerId()
        self.base_paths = "/variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel"

        self.panel_0 = self.base_paths + '/stack_panel/down_panel/panel_0'
        self.panel_1 = self.base_paths + '/stack_panel/down_panel/panel_1'
        self.M_scroll_view = self.panel_0 + '/M_scroll_view'

        self.scroll_view_path = ''
        self.index = param.get('index', 0)

    # =========================== 生命周期 ===========================

    def Update(self):
        pass

    def Create(self):
        """UI 创建完成：解析滚动视图路径并选中初始面板"""
        self.scroll_view_path = (
            "/scroll_mouse/scroll_view/stack_panel/background_and_viewport/scrolling_view_port/scrolling_content"
            if not self.GetChildrenName(self.M_scroll_view).count('scroll_touch')
            else "/scroll_touch/scroll_view/panel/background_and_viewport/scrolling_view_port/scrolling_content"
        )
        self._selpanel(self.index, True)

    def Init(self):
        pass

    # =========================== 面板切换 ===========================

    def _selpanel(self, index, isinit=False):
        """切换右侧显示面板。index 对应 nr0/nr1/nr2..."""
        if isinit:
            toggle_path = (self.panel_0 + '/M_scroll_view' + self.scroll_view_path
                           + '/stack_panel/tg%s/M_toggle' % index)
            self.GetBaseUIControl(toggle_path).asSwitchToggle().SetToggleState(True)
        # 隐藏旧面板
        old_path = self.panel_1 + '/M_scroll_view' + self.scroll_view_path + '/nr%s' % self.index
        self.GetBaseUIControl(old_path).SetVisible(False)
        # 显示新面板
        new_path = self.panel_1 + '/M_scroll_view' + self.scroll_view_path + '/nr%s' % index
        self.GetBaseUIControl(new_path).SetVisible(True)
        self.index = index

    # _selpanel: 左侧 toggle 切换右侧面板可见性

    # =========================== 按钮绑定 ===========================

    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#setting_close_btn')
    def setting_close_btn(self, args):
        """右上角 × 关闭界面"""
        clientApi.PopScreen()

    # setting_close_btn: 关闭设置界面

    @ViewBinder.binding(ViewBinder.ToggleFilter | ViewBinder.BF_ToggleChanged, '#setting_gn_toggle_jh')
    def setting_gn_toggle_jh(self, args):
        """左侧分类 toggle 切换"""
        self._selpanel(args['index'])

    # setting_gn_toggle_jh: 左侧分类切换

    # -------------------------------------- 通用设置（nr0） --------------------------------------

    @ViewBinder.binding(ViewBinder.ToggleFilter | ViewBinder.BF_ToggleChanged, '#setting_example_toggle_jh')
    def setting_example_toggle_jh(self, args):
        """示例 toggle 开关：写入客户端配置"""
        self.mclienSystem.ClientConfig['example_toggle'] = args['state']

    @ViewBinder.binding(ViewBinder.BF_BindBool, '#setting_example_toggle_nr')
    def setting_example_toggle_nr(self):
        """示例 toggle 开关：读取客户端配置"""
        return self.mclienSystem.ClientConfig.get('example_toggle', False)

    @ViewBinder.binding(ViewBinder.BF_EditChanged | ViewBinder.BF_EditFinished, '#setting_example_edit_jh')
    def setting_example_edit_jh(self, args):
        """示例 edit_box：写入客户端配置"""
        self.mclienSystem.ClientConfig['example_text'] = args.get('Text', '')
        return ViewRequest.Refresh

    @ViewBinder.binding(ViewBinder.BF_BindString, '#setting_example_edit_nr')
    def setting_example_edit_nr(self):
        """示例 edit_box：读取客户端配置"""
        return self.mclienSystem.ClientConfig.get('example_text', '')

    # -------------------------------------- 高级设置（nr1） --------------------------------------

    @ViewBinder.binding(ViewBinder.ToggleFilter | ViewBinder.BF_ToggleChanged, '#setting_advanced_toggle_jh')
    def setting_advanced_toggle_jh(self, args):
        """高级设置 toggle：写入客户端配置"""
        self.mclienSystem.ClientConfig['advanced_toggle'] = args['state']

    @ViewBinder.binding(ViewBinder.BF_BindBool, '#setting_advanced_toggle_nr')
    def setting_advanced_toggle_nr(self):
        """高级设置 toggle：读取客户端配置"""
        return self.mclienSystem.ClientConfig.get('advanced_toggle', False)

    # 设置界面 complete
