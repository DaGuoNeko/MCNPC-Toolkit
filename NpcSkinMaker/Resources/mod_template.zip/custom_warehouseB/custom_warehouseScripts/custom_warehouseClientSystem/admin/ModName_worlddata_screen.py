# -*- coding: utf-8 -*-
"""跨存档数据导入导出界面 ScreenNode 模板（可选注入）

功能：
- 把服务端存档数据（主数据 + 全局配置）导出到客户端配置文件（跨存档持久）
- 到新存档后读取并覆盖写入服务端
- 仅 OP 可用；导出覆盖需三次确认 + 服务端深拷贝备份 + 超时还原
- 入口：客户端系统 self.Open_ModName_worlddata_screen()

占位命名规则：
- 类名: ModName_worlddata_screen（生成后替换为实际 Mod 名）
- 注册路径: ModName_worlddata_screen.main
- 参数传入: {"cs": self} 接收 ClientSystem 实例（self.mclienSystem）
"""
import time

import mod.client.extraClientApi as clientApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
ScreenNode = clientApi.GetScreenNodeCls()
CF = clientApi.GetEngineCompFactory()
LevelID = clientApi.GetLevelId()


class ModName_worlddata_screen(ScreenNode):

    def __init__(self, namespace, name, param):
        super(ModName_worlddata_screen, self).__init__(namespace, name, param)
        self.mclienSystem = param["cs"]
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        self.Playerid = clientApi.GetLocalPlayerId()
        self.base_paths = "/variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel"

        self.loading_panel = self.base_paths + '/loading_panel'
        self.loading_text = self.loading_panel + '/image_panel/text'

        self.beizhuname = ''

        self.tick = 0

        # 待操作的数据 key 列表
        self.impdatakey = []
        # True=获取模式（从服务端拉数据存到客户端配置）；False=覆盖模式（从客户端配置写入服务端）
        self.isimp = False

        # 是否读取过本地跨存档数据
        self.isload = False
        # 超时计数
        self.erro_disp = 0

        # 正在操作的备份数据备注名
        self.databeizhuname = ''

        # 跨存档需要迁移的数据 key 列表（启动时从服务端获取）
        self._datakeys = [CG.KV_KEY_MAIN, CG.KV_KEY_GLOBAL_CONFIG]

    def getdatakeys(self):
        """跨存档需要迁移的数据 key 列表"""
        return self._datakeys

    def Update(self):
        self.tick += 1
        if self.tick % 30 == 0:
            self.load()

    def Create(self):
        self.mclienSystem.RegisterTipsPanel(self, self.base_paths)
        self.mclienSystem.ResiPopup(self, self.base_paths)
        # 启动时向服务端请求当前需要迁移的 key 列表
        self.mclienSystem.TS({'lx': 'getworlddatakeys'}, self._on_getkeys, 'getworlddatakeys')

    def _on_getkeys(self, data):
        """服务端返回迁移 key 列表后更新本地缓存"""
        keys = (data or {}).get('keys')
        if keys and isinstance(keys, list):
            self._datakeys = keys

    # _on_getkeys: 动态获取跨存档迁移 key 列表

    def Init(self):
        pass

    def _backdata(self, data):
        """TS 回调：服务端返回单个 key 的数据（获取模式）或写入完成（覆盖模式）"""
        key = data.get('key', '')
        if self.isimp:
            if key in self.impdatakey:
                if self.databeizhuname in self.mclienSystem.WorldData['data']:
                    self.mclienSystem.WorldData['data'][self.databeizhuname]['data'][key] = data.get('data')

        if key in self.impdatakey:
            self.impdatakey.remove(key)

        if not self.impdatakey:
            if self.isimp:
                self.GetBaseUIControl(self.loading_panel).SetVisible(False, False)
                self.mclienSystem.ShowTipsPanel('已完成添加到跨存档数据栏。')
                self.mclienSystem.WorldConfigData()
            else:
                self.GetBaseUIControl(self.loading_panel).SetVisible(False, False)
                self.mclienSystem.ShowTipsPanel('导出数据完成！')
            self.UpdateScreen()
            self.GetBaseUIControl(self.loading_text).asLabel().SetText('')

    # _backdata: 单个 key 操作完成回调，全部完成后保存/提示

    def load(self):
        """每 30 tick 执行一次：逐个 key 向服务端发请求"""
        if self.impdatakey:
            self.erro_disp += 1
            if self.erro_disp >= 64:
                if self.isimp:
                    self.mclienSystem.ShowTipsPanel('操作超时!')
                else:
                    self.mclienSystem.ShowTipsPanel('覆盖数据超时!正在还原备份数据!')
                    self.mclienSystem.TS({'lx': 'BackWorldData'}, None, 'BackWorldData')
                self.GetBaseUIControl(self.loading_panel).SetVisible(False, False)
                self.erro_disp = 0
                self.impdatakey = []

            for _ in self.impdatakey:
                if self.isimp:
                    self.mclienSystem.TS({'lx': 'GetWorldData', 'key': _}, self._backdata, 'GetWorldData')
                    self.GetBaseUIControl(self.loading_text).asLabel().SetText('正在获取 %s 数据中...' % _)
                else:
                    data = self.mclienSystem.WorldData['data'][self.databeizhuname]['data'].get(_, None)
                    self.mclienSystem.TS({'lx': 'SetWorldData', 'key': _, 'data': data}, self._backdata, 'SetWorldData')
                    if _ == '__BackUp__':
                        self.GetBaseUIControl(self.loading_text).asLabel().SetText('正在临时备份数据...')
                    else:
                        self.GetBaseUIControl(self.loading_text).asLabel().SetText('正在覆盖 %s 数据中...' % _)
                break

    # load: 逐个 key 发 TS，取首个 break（等回调移除后再发下一个）

    # -------------------------------------- 按钮绑定 --------------------------------------

    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#worlddata_close_btn')
    def worlddata_close_btn(self, args):
        """右上角 × 关闭界面"""
        clientApi.PopScreen()

    # worlddata_close_btn: 关闭跨存档界面

    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#worlddata_imp_list_btn')
    def worlddata_imp_list_btn(self, args):
        """读取跨存档数据：从客户端配置文件读入 WorldData"""
        self.mclienSystem.WorldConfigData(False)
        self.isload = True
        self.mclienSystem.ShowTipsPanel('读取跨存档数据成功!')
        return ViewRequest.Refresh

    # worlddata_imp_list_btn: 读取客户端配置文件到内存

    @ViewBinder.binding(ViewBinder.BF_EditChanged | ViewBinder.BF_EditFinished, '#worlddata_name_jh')
    def worlddata_name_jh(self, args):
        self.beizhuname = args.get('Text', '')
        return ViewRequest.Refresh

    @ViewBinder.binding(ViewBinder.BF_BindString, '#worlddata_name_nr')
    def worlddata_name_nr(self):
        return self.beizhuname

    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#worlddata_add_btn')
    def worlddata_add_btn(self, args):
        """添加跨存档数据：输入备注名 → 确认 → 逐个 key 从服务端拉取 → 存入客户端配置"""
        if not (self.mclienSystem.PlayerPermission or {}).get('isop'):
            self.mclienSystem.ShowTipsPanel('需要 OP 权限')
            return
        if not self.isload:
            self.mclienSystem.ShowTipsPanel('请先点击一次 §e读取跨存档数据')
            return
        if not self.beizhuname:
            self.mclienSystem.ShowTipsPanel('备注名不能为空!')
            return
        if self.beizhuname in self.mclienSystem.WorldData['data']:
            self.mclienSystem.ShowTipsPanel('跨存档数据已有该备注名的数据!请重新填写')
            return

        def on():
            self.impdatakey = self.getdatakeys()[:]
            self.GetBaseUIControl(self.loading_panel).SetVisible(True, False)
            self.isimp = True
            self.erro_disp = 0
            self.databeizhuname = self.beizhuname
            self.mclienSystem.WorldData['data'][self.beizhuname] = {
                'data': {},
                'stime': time.time(),
                'levelid': clientApi.GetLevelId()
            }

        self.mclienSystem.OpenPopup('确认添加一份数据到跨存档数据?', on)

    # worlddata_add_btn: 备份当前存档数据到客户端配置文件

    # -------------------------------------- 列表 --------------------------------------

    @ViewBinder.binding(ViewBinder.BF_BindInt, '#worlddata_count')
    def worlddata_count(self):
        if self.isload and self.mclienSystem.WorldData['data']:
            return len(self.mclienSystem.WorldData['data'])
        return 0

    # worlddata_count: 列表行数

    @ViewBinder.binding_collection(ViewBinder.BF_BindString, 'worlddata_grid', '#worlddata_item_name')
    def worlddata_item_name(self, index):
        if self.isload and self.mclienSystem.WorldData['data']:
            keys = self.mclienSystem.WorldData['data'].keys()
            if index < len(keys):
                worid = keys[index]
                stored_keys = self.mclienSystem.WorldData['data'][worid].get('data', {}).keys()
                state = sorted(stored_keys) == sorted(self.getdatakeys())
                stime = self.mclienSystem.WorldData['data'][worid].get('stime', 0)
                tag = '§a数据完整§f' if state else '§c数据不完整,请删除!§f'
                return str('%s [%s] 时间: %s' % (worid, tag, M.timestamp_to_time(stime)))
        return ''

    # worlddata_item_name: 行文本（备注名 + 完整性 + 时间）

    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#worlddata_item_btn')
    def worlddata_item_btn(self, args):
        """导出至存档：三次确认 → 校验完整性 → 逐个 key 写入服务端"""
        if not (self.mclienSystem.PlayerPermission or {}).get('isop'):
            self.mclienSystem.ShowTipsPanel('需要 OP 权限')
            return
        if not self.isload:
            self.mclienSystem.ShowTipsPanel('请先点击一次 §e读取跨存档数据')
            return

        collection_index = args.get('#collection_index', -1)
        keys = self.mclienSystem.WorldData['data'].keys()
        if collection_index < 0 or collection_index >= len(keys):
            return
        key = keys[collection_index]

        def on():
            def on1():
                def on2():
                    stored_keys = self.mclienSystem.WorldData['data'][key].get('data', {}).keys()
                    state = sorted(stored_keys) == sorted(self.getdatakeys())
                    if state:
                        self.impdatakey = self.getdatakeys()[:]
                        self.impdatakey.insert(0, '__BackUp__')
                        self.impdatakey.append('__BackUpEnd__')
                        self.GetBaseUIControl(self.loading_panel).SetVisible(True, False)
                        self.isimp = False
                        self.erro_disp = 0
                        self.databeizhuname = key
                    else:
                        self.mclienSystem.ShowTipsPanel('数据不完整，无法导出!')

                self.mclienSystem.OpenPopup(
                    '3次确认导出至本存档?\n§c会覆盖存档所有数据!!!\n会覆盖存档所有全局配置！！！',
                    on2, '§c高危操作!警告!警告!警告!'
                )

            self.mclienSystem.OpenPopup(
                '2次确认导出至本存档?\n§c会覆盖存档所有数据!!!\n会覆盖存档所有全局配置！！！',
                on1, '§c高危操作!警告!警告!警告!'
            )

        self.mclienSystem.OpenPopup(
            '确认导出至本存档?\n§c会覆盖存档所有数据!!!\n会覆盖存档所有全局配置！！！',
            on, '§c高危操作!警告!警告!警告!'
        )

    # worlddata_item_btn: 三次确认 → 深拷贝备份 → 逐 key 覆盖 → 落盘刷新

    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#worlddata_item_remove_btn')
    def worlddata_item_remove_btn(self, args):
        """删除跨存档数据条目"""
        collection_index = args.get('#collection_index', -1)
        if not self.isload or not self.mclienSystem.WorldData['data']:
            return
        keys = self.mclienSystem.WorldData['data'].keys()
        if collection_index < 0 or collection_index >= len(keys):
            return
        key = keys[collection_index]

        def on():
            del self.mclienSystem.WorldData['data'][key]
            self.mclienSystem.ShowTipsPanel('成功删除 %s 跨存档数据!' % key)
            self.mclienSystem.WorldConfigData()
            try:
                self.UpdateScreen(True)
            except TypeError:
                self.UpdateScreen()

        self.mclienSystem.OpenPopup('确认删除 %s 跨存档数据?' % key, on, '§c警告!警告!警告!')

    # worlddata_item_remove_btn: 确认后删除条目并保存客户端配置

    # 跨存档界面 complete
