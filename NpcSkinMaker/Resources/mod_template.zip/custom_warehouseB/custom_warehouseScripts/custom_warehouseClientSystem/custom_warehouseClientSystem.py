# -*- coding: utf-8 -*-
import random
import time
import uuid
import mod.client.extraClientApi as clientApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

ClientSystem = clientApi.GetClientSystemCls()
CF = clientApi.GetEngineCompFactory()
LevelID = clientApi.GetLevelId()
ME = clientApi.GetMinecraftEnum()
compConfigClient = CF.CreateConfigClient(LevelID)


class custom_warehouseClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(custom_warehouseClientSystem, self).__init__(namespace, systemName)
        import custom_warehouseScripts.custom_warehouseClientSystem.utils as utils
        import custom_warehouseScripts.custom_warehouseClientSystem.ClaAnyEvent as CAE
        self.utils = utils
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.utils"""
        self.base_paths = "/variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel"
        self.Playerid = clientApi.GetLocalPlayerId()
        self.custom_warehouseUINode = None
        self.BackFun = {}

        # 联动模块：统一联动模组设置（延迟获取，配合 GetMod 重试）
        # 每个联动模块声明为 None，在 GetMod() 中通过 GetSystem 获取
        # 所有使用处必须用 if self.XXX: 做 null 守卫，确保未联动时不崩溃
        self.XxxxModClass = None             # 示例：xxxx 模组联动（改成实际模组名）
        """:type: object | None"""

        # 物品浏览系统
        self._AllItemsList = []
        self.JEIStyleSorterClass = None
        """:type: JEIStyleSorter | None"""

        self.ListenEvents()

        self.utils.ClickMappings(self, self.ClickEvent, self.UserEvent)

        # 服务端发起请求的处理器（lx 方法路由），用于响应服务端 TC
        self.ClaAnyEvent = CAE.ClaAnyEvent(self)
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.ClaAnyEvent.ClaAnyEvent"""

        # 每秒触发
        CF.CreateGame(LevelID).AddRepeatedTimer(1.0, self.timed1s)

        # 用于检查通信
        self.CompTime05 = CF.CreateGame(LevelID).AddRepeatedTimer(0.5, self.Time05Event)

        # 用于存放各个界面的操作CD
        self.UserUITickList = {}

        # 玩家权限信息
        self.PlayerPermission = {
            'isop': False
        }

        # 跨存档数据（存入客户端配置文件，跨存档持久）
        self.WorldData = {'data': {}}

        # 客户端本地配置数据（不跨存档，仅当前客户端有效）
        self.ClientConfig = {}

    # =========================== 事件注册 ===========================

    def ListenEvents(self):
        """集中注册所有引擎事件和自定义事件（含注释说明每个事件的用途）"""
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
                            "UiInitFinished", self, self.InitUi)
        # 服务端→客户端 AnyEvent 通信
        self.ListenForEvent(CG.Mod_Name, CG.S_Name, "AnyEvent", self, self.AnyEvent)
        # 可选：背包变更、手持物品切换、键盘按键等
        # self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
        #                     "InventoryItemChangedClientEvent", self, self.OnInventoryItemChanged)
        # self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
        #                     "OnCarriedNewItemChangedClientEvent", self, self.OnCarriedNewItemChanged)

    # =========================== 定时器 ===========================

    def timed1s(self):
        if not getattr(self, '_timed_', None):
            rantime = round(random.uniform(1.0, 3.0), 2)
            timed = CF.CreateGame(LevelID).AddTimer(rantime, self.randomtick)
            setattr(self, '_timed_', timed)

    def randomtick(self):
        """随机刻触发"""
        setattr(self, '_timed_', None)
        self.GetPlayerPermission()

    def GetPlayerPermission(self):
        """向服务端获取玩家权限"""
        def getopdata(data):
            self.PlayerPermission.update(data)
        self.TS({'lx': 'GetPlayerPermission'}, getopdata, 'GetPlayerPermission')

    def Update(self):
        """每帧调用：减少操作界面 CD"""
        if self.UserUITickList:
            for _ in list(self.UserUITickList):
                if self.UserUITickList[_] - time.time() <= 0:
                    del self.UserUITickList[_]

    def AddUserUiCd(self, key='none', times=1):
        """给予操作界面 CD；返回 True 表示 CD 中"""
        if key in self.UserUITickList:
            return True
        if times <= 0.0:
            return False
        self.UserUITickList[key] = time.time() + times
        return False

    def Time05Event(self):
        """轮询 BackFun 中超时的回调（>10s），用失败结构兜底并清理"""
        for _d in list(self.BackFun):
            if self.BackFun.get(_d, None):
                if time.time() - self.BackFun[_d]['time'] > 10:
                    try:
                        self.BackFun[_d]['back']({'data': {}, 'state': False})
                        del self.BackFun[_d]
                    except:
                        del self.BackFun[_d]

    # =========================== 通信：TS/AnyEvent ===========================

    def AnyEvent(self, args):
        """服务端消息入口：
        - 含 'data'：服务端发起的请求 → ClaAnyEvent 处理
        - 否则：服务端对客户端请求的回调 → 派发到 BackFun
        """
        if 'data' in args:
            self.ClaAnyEvent.AnyEvent(args)
            return
        back = args['back']
        data = args['backdata']
        if self.BackFun.get(back, None):
            if type(self.BackFun[back]['back']) is tuple:
                for _ in self.BackFun[back]['back']:
                    _(data)
                del self.BackFun[back]
            else:
                self.BackFun[back]['back'](data)
                del self.BackFun[back]
        else:
            print '服务器无法找到客户端回调', back

    def TS(self, data, back=None, eventsuid=''):
        """向服务端发送请求并接收回调（data={'lx': 'xxx', ...}）"""
        if eventsuid:
            uids = eventsuid
        else:
            uids = uuid.uuid4().hex[:6]
        if self.BackFun.get(eventsuid, None) is None:
            if back:
                self.BackFun[uids] = {'back': back, 'time': time.time()}
            self.NotifyToServer('AnyEvent', {'data': data, 'back': uids if back else None})
            return True
        else:
            return False, '正在处理中...请稍后'

    # =========================== UI 初始化 ===========================

    def InitUi(self, args):
        """引擎 UI 就绪后注册界面和 HUD。加载联动模组及可选键盘绑定"""
        # 注册 UI 屏幕（根据实际需要取消注释）
        # clientApi.RegisterUI("custom_warehouse", "ModName_screen",
        #     "custom_warehouseScripts.custom_warehouseClientSystem.user.ModName_user_screen.ModName_user_screen",
        #     "ModName_screen.main")
        # self.custom_warehouseUINode = clientApi.CreateUI("custom_warehouse", "ModName_screen",
        #     {"isHud": 1, "cs": self})

        # 可选：注册自定义按键（参考 quest_engine IntitPcKey 模式）
        # CF.CreatePlayerView(LevelID).RegisterCustomKeyMapping("打开ModName", 73, "ModName系统")

        # 加载联动模组
        self.GetMod()

        # 加载跨存档数据
        self.WorldConfigData(False)

    def GetMod(self, isreget=False):
        """统一联动模组设置：客户端通过 GetSystem 获取其他 mod 的系统实例。
        
        设计要点：
        - 客户端在 InitUi 中调用，此时所有 mod 的 client system 已经注册完成
        - 但部分联动 mod 可能加载较慢，故通过 5s 定时器重试一次（isreget=True）
        - GetSystem 失败时返回 None（不抛异常），所有使用处必须做 null 守卫
        - 按需复制此行添加更多联动：self.XxxClass = clientApi.GetSystem('mod_id', 'mod_idClientSystem')
        """
        self.XxxxModClass = clientApi.GetSystem('xxxx', 'xxxxClientSystem')
        # 5s 后重试一次，避免目标 mod 尚未加载完成
        if not isreget:
            CF.CreateGame(LevelID).AddTimer(5.0, self.GetMod, True)

    # =========================== 点击/交互事件 ===========================

    def ClickEvent(self, isdown, IsTouchWithMouse):
        if isdown:
            pass
        else:
            pass

    def UserEvent(self, isdown, IsTouchWithMouse):
        """使用触发：右键/长按时触发（具体逻辑由子类实现）"""
        if isdown:
            pass
        return False

    # =========================== 工具方法 ===========================

    def ToPlayerMsg(self, txt):
        """通用给玩家发送聊天栏消息"""
        CF.CreateTextNotifyClient(self.Playerid).SetLeftCornerNotify(txt)

    def GetItemaux(self, itemdata, isench=False):
        """获取物品 Aux 渲染 id"""
        itemid = 0
        isch = M.GetItemisEnchant(itemdata)
        if itemdata:
            if isench:
                isch = isench
            if itemdata.get('ech', None):
                isch = itemdata.get('ech', False)
            itembasedata = CF.CreateItem(clientApi.GetLevelId()).GetItemBasicInfo(
                itemdata['newItemName'], itemdata['newAuxValue'], isch)
            if itembasedata:
                itemid = itembasedata.get('id_aux', 0)
        return itemid

    # =========================== 弹窗 ===========================

    def ResiPopup(self, *args, **kwargs):
        """注册弹窗"""
        return self.utils.Popup(self, *args, **kwargs)

    def OpenPopup(self, *args, **kwargs):
        """打开弹窗"""
        uinode = clientApi.GetTopUINode()
        __PopupClass__ = getattr(uinode, '__PopupClass__', None)
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.utils.Popup | None"""
        if uinode and __PopupClass__:
            __PopupClass__.Popup(*args, **kwargs)

    # =========================== 数字选择器 ===========================

    def RegisterContPanel(self, *args, **kwargs):
        return self.utils.count_controls(*args, **kwargs)

    def OpenContPanel(self, *args, **kwargs):
        uinode = clientApi.GetTopUINode()
        __ContPanelClass__ = getattr(uinode, '__ContPanelClass__', None)
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.utils.count_controls | None"""
        if uinode and __ContPanelClass__:
            __ContPanelClass__.Open(*args, **kwargs)

    # =========================== 物品选择面板 ===========================

    def RegisterItemPicker(self, ui_node, create_path):
        """注册物品选择面板（全自动，类似 RegisterContPanel）。自动加载物品数据。"""
        self.ContAllItems()
        return self.utils.ItemPicker(ui_node, create_path, self)

    def OpenItemPicker(self, bbtype=0, back=None):
        """打开物品选择面板"""
        uinode = clientApi.GetTopUINode()
        __ItemPickerClass__ = getattr(uinode, '__ItemPickerClass__', None)
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.utils.ItemPicker | None"""
        if uinode and __ItemPickerClass__:
            __ItemPickerClass__.Open(bbtype, back)

    # =========================== 颜色选择面板 ===========================

    def RegisterColorPicker(self, ui_node, create_path):
        """注册颜色选择面板"""
        return self.utils.ColorPicker(ui_node, create_path, self)

    def OpenColorPicker(self, back=None, color=None):
        """打开颜色选择面板。color: 'R,G,B' 默认颜色，不传默认红色"""
        uinode = clientApi.GetTopUINode()
        __ColorPickerClass__ = getattr(uinode, '__ColorPickerClass__', None)
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.utils.ColorPicker | None"""
        if uinode and __ColorPickerClass__:
            __ColorPickerClass__.Open(back, color)

    # =========================== 提示面板 ===========================

    def RegisterTipsPanel(self, uinode, create_path):
        if 'M_Tips_Panel' not in uinode.GetChildrenName(create_path):
            uinode.CreateChildControl('%s.M_Tips_Panel' % (CG.Ui_CommonName), 'M_Tips_Panel',
                                      uinode.GetBaseUIControl(create_path))

    def ShowTipsPanel(self, text, isdisp=False):
        if isdisp:
            CF.CreateGame(LevelID).AddTimer(0.5, self.ShowTipsPanel, text)
            return
        uinode = clientApi.GetTopUINode()
        if uinode:
            path = self.base_paths + '/M_Tips_Panel'
            uicont = uinode.GetBaseUIControl(path)
            uinode.GetBaseUIControl(path + '/tips_text').asLabel().SetText(text)
            uicont.SetVisible(True, False)
            uicont.StopAnimation()
            uicont.PlayAnimation()

    def RegisterItemsTipsPanel(self, uinode, create_path):
        if 'M_ITEMS_TIPS_PANEL' not in uinode.GetChildrenName(create_path):
            uinode.CreateChildControl('%s.M_ITEMS_TIPS_PANEL' % (CG.Ui_CommonName), 'M_ITEMS_TIPS_PANEL',
                                      uinode.GetBaseUIControl(create_path))

    def ShowItemsTipsPanel(self, itemdata, exid=True, istext=False):
        uinode = clientApi.GetTopUINode()

        def ontext(txt):
            if uinode:
                path = self.base_paths + '/M_ITEMS_TIPS_PANEL'
                uicont = uinode.GetBaseUIControl(path)
                uinode.GetBaseUIControl(path + '/image/text').asLabel().SetText(txt)
                uicont.SetVisible(True, False)
                uicont.StopAnimation()
                uicont.PlayAnimation()

        if istext:
            ontext(itemdata)
            return

        # 示例：联动模组的物品信息显示（按需修改）
        # if isinstance(itemdata, dict) and self.XxxxModClass:
        #     self.XxxxModClass.OnItemsTips(itemdata)
        #     return

        text = CF.CreateItem(LevelID).GetItemFormattedHoverText(
            itemdata.get('newItemName', 'air'), itemdata.get('newAuxValue', 0),
            False, itemdata.get('userData', {}))
        if 'extext' in itemdata:
            text += itemdata['extext']
        if exid:
            text += '\nID: ' + '§9%s\n' % (itemdata.get('newItemName', 'air'))
            text += '§fAux: ' + '§9%s' % (itemdata.get('newAuxValue', 0))
        ontext(text)

    # =========================== 屏幕模糊 ===========================

    def SetScreenBlur(self, enable, radius=1.0):
        compProcess = CF.CreatePostProcess(LevelID)
        compProcess.SetEnableGaussianBlur(enable)
        if enable:
            compProcess.SetGaussianBlurRadius(radius)

    # =========================== 跨存档数据 ===========================

    def WorldConfigData(self, isava=True):
        """跨存档数据读取与保存（存入客户端配置文件，跨存档持久）
        :param isava: True=保存; False=读取
        """
        if isava:
            compConfigClient.SetConfigData('ModName_WorldData.json', self.WorldData, True)
        else:
            worlddata = compConfigClient.GetConfigData('ModName_WorldData.json', True)
            if worlddata:
                self.WorldData = worlddata

    # =========================== 屏幕 ===========================

    def Open_ModName_user_screen(self):
        """打开用户主界面"""
        clientApi.PushScreen('custom_warehouse', 'ModName_screen', {"cs": self})

    def Open_ModName_worlddata_screen(self):
        """打开跨存档数据管理界面（OP 专用）"""
        clientApi.PushScreen(CG.Mod_Name, 'ModName_worlddata_screen', {"cs": self})

    def Open_ModName_setting_screen(self):
        """打开全局设置界面"""
        clientApi.PushScreen(CG.Mod_Name, 'ModName_setting_screen', {"cs": self})

    def UpTopUI(self, layer=1):
        """兼容占位：防止 Popup 内部调用报 AttributeError"""
        pass

    # =========================== HUD 屏幕（可选注入） ===========================

    def RegisterHudScreen(self):
        """注册并创建 HUD 常驻界面（isHud=1，不阻挡游戏操作）。
        在 InitUi 中调用，HUD 屏幕模板需存在时才生效。"""
        clientApi.RegisterUI(CG.Mod_Name, "ModName_hud_screen",
            "custom_warehouseScripts.custom_warehouseClientSystem.ModName_hud_screen.ModName_hud_screen",
            "ModName_hud_screen.main")
        self.ModNameHudUINode = clientApi.CreateUI(CG.Mod_Name, "ModName_hud_screen",
            {"isHud": 1, "cs": self})

    def CloseHudScreen(self):
        """关闭 HUD 常驻界面"""
        if getattr(self, 'ModNameHudUINode', None):
            self.ModNameHudUINode.SetRemove()
            self.ModNameHudUINode = None

    # =========================== 物品浏览器 ===========================

    def ContAllItems(self, chunk_size=100):
        """加载全部游戏物品到 _AllItemsList，并初始化 JEIStyleSorter"""

        def back(data):
            lists = data['itemslist']
            asitemlist = []
            for k in lists:
                if 'minecraft:element_' in k or 'minecraft:hard_' in k:
                    continue
                itembaseinfo = CF.CreateItem(LevelID).GetItemBasicInfo(k)
                if itembaseinfo:
                    asitemlist.append((k, {
                        'cn': itembaseinfo.get('itemName', 'unknown'),
                        'idaux': itembaseinfo.get('id_aux', 0),
                        'itemCategory': itembaseinfo.get('itemCategory', ''),
                        'itemType': itembaseinfo.get('itemType', '')
                    }))
                else:
                    asitemlist.append((k, {
                        'cn': 'unknown', 'idaux': 0,
                        'itemCategory': '', 'itemType': ''
                    }))
            self._AllItemsList = asitemlist
            self.JEIStyleSorterClass = JEIStyleSorter(self._AllItemsList, self)

        if len(self._AllItemsList) <= 100:
            self.TS({'lx': 'getallitems'}, back)


# =========================== JEI 风格物品排序器 ===========================

class JEIStyleSorter(object):
    """JEI 风格物品分页排序器：支持搜索/翻页/背包模式"""

    CATEGORY_ORDER = {
        'construction': 0, 'equipment': 1, 'items': 2, 'custom': 3, '': 4
    }
    ITEM_TYPE_ORDER = {
        'block': 0, 'pickaxe': 1, 'axe': 2, 'shovel': 3, 'hoe': 4,
        'sword': 5, 'shears': 6, 'armor': 7, 'food': 8, 'potion': 9,
        'book': 10, 'bucket': 11, 'fishing_rod': 12, 'clock': 13,
        'compass': 14, 'dye': 15, 'trident': 16, 'crossbow': 17,
        'custom_ranged_weapon': 18, '': 19
    }

    def __init__(self, all_items, mclass, items_per_page=100):
        self.mclass = mclass
        self.all_items = self._sort_jei_style(all_items)
        self.items_per_page = items_per_page
        self.current_page = 0
        self.search_term = ""
        self.filtered_items = self.all_items[:]
        self.total_pages = self._calculate_total_pages()
        self._update_page_info()
        self.is_backpack_mode = False

    def _sort_jei_style(self, items):
        def get_sort_key(item):
            item_id, item_data = item
            is_vanilla = 1 if item_id.startswith('minecraft:') else 0
            category = item_data.get('itemCategory', '')
            category_order = self.CATEGORY_ORDER.get(category, 999)
            item_type = item_data.get('itemType', '')
            item_type_order = self.ITEM_TYPE_ORDER.get(item_type, 999)
            cn_name = item_data.get('cn', '')
            return (-is_vanilla, category_order, item_type_order, cn_name, item_id)
        return sorted(items, key=get_sort_key)

    def _calculate_total_pages(self):
        if not self.filtered_items:
            return 1
        return (len(self.filtered_items) - 1) // self.items_per_page + 1

    def _update_page_info(self):
        self.total_pages = self._calculate_total_pages()
        self.page_info = "%s/%s" % (self.current_page + 1, self.total_pages)
        start_idx = self.current_page * self.items_per_page
        end_idx = start_idx + self.items_per_page
        self.current_items = self.filtered_items[start_idx:end_idx]

    def _filter_items(self, search_term):
        if not search_term:
            return self.all_items[:]
        search_lower = search_term.lower()
        filtered = []
        for item in self.all_items:
            item_id, data = item
            cn_name = data.get('cn', '').lower()
            if search_lower in item_id.lower() or search_lower in cn_name:
                filtered.append(item)
        return filtered

    def search(self, search_term=''):
        self.search_term = self.search_term.strip()
        self.filtered_items = self._filter_items(self.search_term)
        self.current_page = 0
        self._update_page_info()
        return self.current_items

    def next_page(self):
        if self.current_page < self.total_pages - 1:
            self.current_page += 1
            self._update_page_info()
        return self.current_items

    def prev_page(self):
        if self.current_page > 0:
            self.current_page -= 1
            self._update_page_info()
        return self.current_items

    def go_to_page(self, page_num):
        if 0 <= page_num < self.total_pages:
            self.current_page = page_num
            self._update_page_info()
        return self.current_items

    def reset(self):
        self.search_term = ""
        self.filtered_items = self.all_items[:]
        self.current_page = 0
        self._update_page_info()
        return self.current_items

    def get_current_state(self):
        return {
            'current_page': self.current_page,
            'total_pages': self.total_pages,
            'page_info': self.page_info,
            'search_term': self.search_term,
            'total_items': len(self.filtered_items),
            'current_page_items': len(self.current_items),
            'items_per_page': self.items_per_page,
            'is_backpack_mode': self.is_backpack_mode,
        }

    def update_items(self, new_items):
        self.all_items = self._sort_jei_style(new_items)
        self.filtered_items = self._filter_items(self.search_term)
        self._update_page_info()

    def set_to_backpack_mode(self):
        self.is_backpack_mode = True
        raw_items = CF.CreateItem(self.mclass.Playerid).GetPlayerAllItems(0, True)
        jei_items = self._convert_backpack_to_jei(raw_items)
        self.update_items(jei_items)
        self.go_to_page(0)
        return self.current_items

    def set_to_normal_mode(self):
        self.is_backpack_mode = False
        self.update_items(self.mclass._AllItemsList)
        return self.current_items

    def _convert_backpack_to_jei(self, raw_items):
        result = []
        for it in (raw_items or []):
            if not it:
                continue
            try:
                cn = CF.CreateItem(LevelID).GetItemBasicInfo(
                    it['newItemName'], it.get('newAuxValue', 0), False)
                cn_name = cn.get('itemName', it['newItemName']) if cn else it['newItemName']
            except Exception:
                cn_name = it['newItemName']
            result.append(('{}:{}'.format(it['newItemName'], it.get('newAuxValue', 0)), {
                'cn': cn_name,
                'idaux': CF.CreateItem(LevelID).GetItemBasicInfo(
                    it['newItemName'], it.get('newAuxValue', 0), False).get('id_aux', 0) if cn else 0,
                'itemCategory': '',
                'itemType': '',
            }))
        return result
