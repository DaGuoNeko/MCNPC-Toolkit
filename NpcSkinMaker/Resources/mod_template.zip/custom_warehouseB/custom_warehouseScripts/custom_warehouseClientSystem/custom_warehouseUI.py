
# -*- coding: utf-8 -*-
import mod.client.extraClientApi as clientApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG


ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
ScreenNode = clientApi.GetScreenNodeCls()
CF = clientApi.GetEngineCompFactory()


class custom_warehouseUI(ScreenNode):
    
    def __init__(self, namespace, name, param):
        super(custom_warehouseUI, self).__init__(namespace, name, param)
        self.mclienSystem = param["cs"]  # 客户端系统
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        self.Playerid = clientApi.GetLocalPlayerId()
        self.base_paths = "/variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel"
            
    def Update(self):
        pass
            
    def Create(self):
        pass
            
    def Init(self):
        pass
