# -*- coding: utf-8 -*-
"""用户主界面 ScreenNode 模板

占位命名规则：
- 类名: ModName_user_screen（生成后替换为实际 Mod 名）
- 注册路径: ModName_screen.main
- 参数传入: {"cs": self} 接收 ClientSystem 实例（self.mclienSystem）
"""

import mod.client.extraClientApi as clientApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

ScreenNode = clientApi.GetScreenNodeCls()
CF = clientApi.GetEngineCompFactory()
LevelID = clientApi.GetLevelId()


class ModName_user_screen(ScreenNode):

    def __init__(self, namespace, name, param):
        super(ModName_user_screen, self).__init__(namespace, name, param)
        self.mclienSystem = param["cs"]
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        self.Playerid = clientApi.GetLocalPlayerId()

        self.base_paths = "/variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel"

        # 在此注册控件和绑定
        # self.RegisterControls()

    # =========================== 控件注册 ===========================

    def RegisterControls(self):
        """注册弹窗、数字选择器、提示面板等公共控件"""
        self.mclienSystem.ResiPopup(self, self.base_paths + '/root_panel')
        self.mclienSystem.RegisterContPanel(self, self.base_paths + '/root_panel')
        self.mclienSystem.RegisterTipsPanel(self, self.base_paths + '/root_panel')
        self.mclienSystem.RegisterItemsTipsPanel(self, self.base_paths + '/root_panel')

    # =========================== 按钮回调示例 ===========================

    # @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#BUTTON_CLOSE')
    # def OnCloseBtn(self, args):
    #     """关闭按钮"""
    #     self.mclienSystem.PopScreenEvent({'screenDef': 'ModName_screen.main'})
