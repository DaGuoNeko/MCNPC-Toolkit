# -*- coding: utf-8 -*-
import copy

import mod.client.extraClientApi as clientApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

ClientSystem = clientApi.GetClientSystemCls()
ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
ScreenNode = clientApi.GetScreenNodeCls()
CF = clientApi.GetEngineCompFactory()
LevelID = clientApi.GetLevelId()
ME = clientApi.GetMinecraftEnum()
compConfigClient = CF.CreateConfigClient(LevelID)


# 自定义弹窗：二次确认弹窗
class Popup(object):

    def __init__(self, mclass, UInode, createpath):
        self.mclass = mclass
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        self.UInode = UInode
        """:type: mod.client.ui.screenNode.ScreenNode"""
        self.createpath = createpath
        self.text = ''
        self.title = '提醒'
        self.callback = None
        self.CreateUI()

    # 创建UI
    def CreateUI(self):
        if 'M_Popup' not in self.UInode.GetChildrenName(self.createpath):
            self.UInode.CreateChildControl('%s.M_Popup' % (CG.Ui_CommonName), 'M_Popup', self.UInode.GetBaseUIControl(self.createpath))

            setattr(self.UInode, '__PopupClass__', self)

            @ViewBinder.binding(ViewBinder.BF_BindString, '#POPUP_TITLE_NAME')
            def _POPUP_TITLE_NAME(ui): return self.POPUP_TITLE_NAME()

            @ViewBinder.binding(ViewBinder.BF_BindString, '#POPUP_TEXT_NAME')
            def _POPUP_TEXT_NAME(ui): return self.POPUP_TEXT_NAME()

            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#POPUP_TEXT_QX_BTN')
            def _POPUP_TEXT_QX_BTN(ui, args): self.POPUP_TEXT_QX_BTN(args)

            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#POPUP_TEXT_QR_BTN')
            def _POPUP_TEXT_QR_BTN(ui, args): self.POPUP_TEXT_QR_BTN(args)

            @ViewBinder.binding(ViewBinder.BF_BindBool, '#POPUP_TEXT_BTN_QR_0_VISIBLE')
            def _POPUP_TEXT_BTN_QR_0_VISIBLE(ui): return self.POPUP_TEXT_BTN_QR_0_VISIBLE()

            @ViewBinder.binding(ViewBinder.BF_BindBool, '#POPUP_TEXT_BTN_QR_1_VISIBLE')
            def _POPUP_TEXT_BTN_QR_1_VISIBLE(ui): return self.POPUP_TEXT_BTN_QR_1_VISIBLE()

            M.CreateDynamicBind(self.UInode, _POPUP_TITLE_NAME)
            M.CreateDynamicBind(self.UInode, _POPUP_TEXT_NAME)
            M.CreateDynamicBind(self.UInode, _POPUP_TEXT_QX_BTN)
            M.CreateDynamicBind(self.UInode, _POPUP_TEXT_QR_BTN)
            M.CreateDynamicBind(self.UInode, _POPUP_TEXT_BTN_QR_0_VISIBLE)
            M.CreateDynamicBind(self.UInode, _POPUP_TEXT_BTN_QR_1_VISIBLE)

    def Popup(self, text, callback, title='提醒'):
        self.text = text
        self.callback = callback
        self.title = title
        self.UInode.GetBaseUIControl(self.createpath + '/M_Popup').SetVisible(True, False)
        self.mclass.UpTopUI()

    def POPUP_TITLE_NAME(self):
        return self.title

    def POPUP_TEXT_NAME(self):
        return self.text

    def POPUP_TEXT_QX_BTN(self, args):
        self.UInode.GetBaseUIControl(self.createpath + '/M_Popup').SetVisible(False, False)
        self.callback = None

    def POPUP_TEXT_QR_BTN(self, args):
        self.UInode.GetBaseUIControl(self.createpath + '/M_Popup').SetVisible(False, False)
        if self.callback:
            self.callback()
            self.mclass.UpTopUI(2)

    def POPUP_TEXT_BTN_QR_0_VISIBLE(self):
        if self.callback:
            return True
        return False

    def POPUP_TEXT_BTN_QR_1_VISIBLE(self):
        if self.callback:
            return False
        return True


# 注册移动按钮管理类
class MoveBtnMappings(object):

    def __init__(self, UInode, MoveDataKeyName, MoveBtnPath=[]):
        self.MoveDataKeyName = MoveDataKeyName
        self.ismove = False
        self.movetimdid = None
        self.savatimdid = None
        self.movebtndata = {}
        self.clickfun = {}
        self._getdata()
        self.UInode = UInode
        """:type: mod.client.ui.screenNode.ScreenNode"""
        self.GetScreenSize = CF.CreateGame(LevelID).GetScreenSize()
        # 🔥【新增】获取实际屏幕分辨率（包括安全区域）
        self.ActualScreenSize = self._get_actual_screen_size()
        # MoveBtnPath的数据 -> ['移动按钮路径', '要移动的UI路径', (坐标偏移x,坐标偏移y), '按钮回调函数']
        self.moveBtnPath = MoveBtnPath
        self._initpos()
        self.ResiBtn()
        # 🔥【新增】初始化时检查并修正超出屏幕的按钮
        self._check_and_fix_out_of_bounds()

    def _get_actual_screen_size(self):
        """
        获取实际屏幕分辨率（包括安全区域）
        返回: (width, height) 元组
        """
        try:
            # 尝试获取设备屏幕分辨率
            device_comp = CF.CreateDevice(clientApi.GetLocalPlayerId())
            screen_size = device_comp.GetScreenSize()
            if screen_size and len(screen_size) >= 2:
                return (screen_size[0], screen_size[1])
        except Exception as e:
            print '获取实际屏幕分辨率异常: %s' % (str(e))

        # 降级方案：使用游戏提供的屏幕大小
        return self.GetScreenSize

    def _clamp_position(self, x, y, btn_width=50, btn_height=50):
        """
        限制按钮位置在屏幕范围内

        参数:
            x, y: 按钮位置（像素）
            btn_width, btn_height: 按钮宽高（像素）

        返回:
            (clamped_x, clamped_y) 限制后的位置
        """
        screen_w, screen_h = self.ActualScreenSize

        # 限制X轴：按钮左边界 >= 0，右边界 <= 屏幕宽度
        clamped_x = max(0, min(x, screen_w - btn_width))

        # 限制Y轴：按钮上边界 >= 0，下边界 <= 屏幕高度
        clamped_y = max(0, min(y, screen_h - btn_height))

        return (clamped_x, clamped_y)

    def _check_and_fix_out_of_bounds(self):
        """
        检查并修正所有超出屏幕的按钮位置
        在初始化时调用，确保保存的位置有效
        """
        screen_w, screen_h = self.ActualScreenSize
        has_fix = False

        for btn_path, data in list(self.movebtndata.items()):
            try:
                pos = data.get('pos', [50.0, 50.0])
                offset = data.get('offset', (0.0, 0.0))

                # 计算实际像素位置
                pixel_x = (screen_w + offset[0]) * (pos[0] / 100.0)
                pixel_y = (screen_h + offset[1]) * (pos[1] / 100.0)

                # 获取按钮尺寸（默认50x50）
                try:
                    uipath = data.get('uipath', '')
                    if uipath:
                        btn_control = self.UInode.GetBaseUIControl(uipath)
                        btn_size = btn_control.GetSize()
                        btn_width = btn_size[0] if btn_size else 50
                        btn_height = btn_size[1] if btn_size else 50
                    else:
                        btn_width, btn_height = 50, 50
                except Exception:
                    btn_width, btn_height = 50, 50

                # 检查是否超出屏幕
                if pixel_x < 0 or pixel_y < 0 or pixel_x + btn_width > screen_w or pixel_y + btn_height > screen_h:
                    # 🔥【修改】超出屏幕直接调用重置方法
                    print '按钮超出屏幕范围: %s，正在重置到默认位置...' % (btn_path)
                    self.ResetBtnPosToDefaultCenter(btn_path)
                    has_fix = True
            except Exception as e:
                print '检查按钮位置异常: %s' % (str(e))

        # 如果有修正，保存数据
        if has_fix:
            self._savadata()

    def _getdata(self):
        movebtndata = compConfigClient.GetConfigData('%s.json' % (self.MoveDataKeyName), True)
        if movebtndata:
            self.movebtndata = movebtndata
        else:
            self.movebtndata = {}

    def _savadata(self):
        compConfigClient.SetConfigData('%s.json' % (self.MoveDataKeyName), self.movebtndata, True)

    def _initpos(self):
        """初始化已保存的按钮位置,没有则跳过"""
        for _ in self.movebtndata:
            self.SetBtnPos(_)

    def SetBtnPos(self, path):
        try:
            data = self.movebtndata.get(path)
            if data:
                pos = data['pos']
                offset = data.get('offset', (0.0, 0.0))
                uipath = data['uipath']
                self.UInode.GetBaseUIControl(uipath).SetPosition(((self.ActualScreenSize[0] + offset[0]) * (pos[0] / 100), (self.ActualScreenSize[1] + offset[1]) * (pos[1] / 100)))
        except Exception:
            print '设置按钮位置异常！'

    def ResetBtnPosToDefaultCenter(self, btn_path):
        """
        重置按钮位置到屏幕中心右上一点

        参数:
            btn_path: str 按钮路径（如 'root_screen_panel/btn_name'）

        返回:
            bool 是否重置成功
        """
        try:
            data = self.movebtndata.get(btn_path)
            if not data:
                print '按钮路径不存在: %s' % (btn_path)
                return False

            # 获取按钮尺寸
            btn_size = data.get('btn_size', [50, 50])
            btn_width, btn_height = btn_size[0], btn_size[1]

            # 计算屏幕中心右上一点的位置
            # 中心: (screen_w/2, screen_h/2)
            # 右上一点: 向右偏移 btn_width/2，向上偏移 btn_height/2
            center_x = (self.ActualScreenSize[0] / 2.0) + (btn_width / 2.0) + 70
            center_y = (self.ActualScreenSize[1] / 2.0) - (btn_height / 2.0) - 70

            # 限制在屏幕范围内
            clamped_x, clamped_y = self._clamp_position(center_x, center_y, btn_width, btn_height)

            # 转换为百分比
            new_pos_x = round((clamped_x / self.ActualScreenSize[0]) * 100.0, 2)
            new_pos_y = round((clamped_y / self.ActualScreenSize[1]) * 100.0, 2)

            # 更新位置
            data['pos'] = [new_pos_x, new_pos_y]
            self.SetBtnPos(btn_path)

            # 保存数据
            self._savadata()

            print '重置按钮位置成功,新位置: [%s, %s]' % (new_pos_x, new_pos_y)
            return True

        except Exception as e:
            print '重置按钮位置异常: %s' % (str(e))
            return False

    def ResetAllBtnsToDefault(self, btnname=''):
        """
        重置所有按钮位置到屏幕中心右上一点

        返回:
            int 成功重置的按钮数量
        """
        success_count = 0
        for btn_path in list(self.movebtndata.keys()):
            if btnname in btn_path:
                if self.ResetBtnPosToDefaultCenter(btn_path):
                    success_count += 1

        print '重置完成，共重置 %d 个按钮' % (success_count)
        return success_count

    def ResiBtn(self):
        """注册移动按钮"""

        for _ in self.moveBtnPath:
            try:
                UIControl = self.UInode.GetBaseUIControl(_[0])
                asbtn = UIControl.asButton()
                asbtn.AddTouchEventParams({"isSwallow": True})
                asbtn.SetButtonTouchDownCallback(self.onButtonTouchDownCallback)
                asbtn.SetButtonTouchMoveCallback(self.onButtonTouchDownCallback)
                asbtn.SetButtonTouchUpCallback(self.onButtonTouchDownCallback)
                asbtn.SetButtonTouchCancelCallback(self.onButtonTouchDownCallback)
                uipos = UIControl.GetGlobalPosition()
                btn_size = UIControl.GetSize()
                btn_width = btn_size[0] if btn_size else 50
                btn_height = btn_size[1] if btn_size else 50
                self.movebtndata[_[0]] = {
                    'pos': [round((uipos[0] / self.ActualScreenSize[0]) * 100.0, 2), round((uipos[1] / self.ActualScreenSize[1]) * 100.0, 2)],
                    'uipath': _[1],
                    'offset': _[2],
                    'btn_size': [btn_width, btn_height]  # 🔥【新增】保存按钮尺寸
                }
                self.clickfun[_[0]] = _[3]
            except Exception:
                print '注册移动按钮异常!'

    def onButtonTouchDownCallback(self, args):
        # print args
        ButtonPath = args['ButtonPath']
        TouchPosX = args['TouchPosX']
        TouchPosY = args['TouchPosY']
        TouchEvent = args['TouchEvent']
        data = self.movebtndata.get(ButtonPath)
        if data:
            if TouchEvent == 1:
                self.ismove = False

                def set_move_true():
                    CF.CreateDevice(clientApi.GetLocalPlayerId()).SetDeviceVibrate(25)
                    CF.CreateGame(clientApi.GetLocalPlayerId()).SetTipMessage('你正在拖动按钮')
                    self.ismove = True

                self.movetimdid = CF.CreateGame(LevelID).AddTimer(1.0, set_move_true)
            elif TouchEvent in [0, 3]:
                CF.CreateGame(LevelID).CancelTimer(self.movetimdid)

                def sava():
                    self._savadata()

                CF.CreateGame(LevelID).CancelTimer(self.savatimdid)
                self.savatimdid = CF.CreateGame(LevelID).AddTimer(1.0, sava)

                if TouchEvent == 0:
                    if ButtonPath in self.clickfun and not self.ismove:
                        if self.clickfun[ButtonPath]:
                            self.clickfun[ButtonPath](args)

                self.ismove = False

            else:
                if self.ismove:
                    # 🔥【新增】移动时限制按钮位置在屏幕范围内
                    btn_size = data.get('btn_size', [50, 50])
                    btn_width, btn_height = btn_size[0], btn_size[1]

                    # 限制位置
                    clamped_x, clamped_y = self._clamp_position(TouchPosX, TouchPosY, btn_width, btn_height)

                    # 转换为百分比并保存
                    data['pos'] = [
                        round((clamped_x / self.ActualScreenSize[0]) * 100.0, 2),
                        round((clamped_y / self.ActualScreenSize[1]) * 100.0, 2)
                    ]
                    self.SetBtnPos(ButtonPath)


# 触屏鼠标使用管理类
class ClickMappings(object):

    def __init__(self, mcla, ClickEventBackFun, UserEventBackFun):
        self.ClickEventBackFun = ClickEventBackFun
        self.UserEventBackFun = UserEventBackFun
        self.mcla = mcla
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        # 是否已进入长按状态
        self.isHoldBefore = False
        # 是否攻击按下
        self.attack = False
        # 是否使用按下
        self.user = False
        self.ListenEvents()

    def ListenEvents(self):
        self.mcla.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), "LeftClickBeforeClientEvent", self, self.LeftClickBeforeClientEvent)
        self.mcla.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), "LeftClickReleaseClientEvent", self, self.LeftClickReleaseClientEvent)
        self.mcla.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), "GetEntityByCoordEvent", self, self.GetEntityByCoordEvent)
        self.mcla.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), "GetEntityByCoordReleaseClientEvent", self, self.GetEntityByCoordReleaseClientEvent)
        self.mcla.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), "HoldBeforeClientEvent", self, self.HoldBeforeClientEvent)
        self.mcla.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), "RightClickBeforeClientEvent", self, self.RightClickBeforeClientEvent)
        self.mcla.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), "RightClickReleaseClientEvent", self, self.RightClickReleaseClientEvent)
        self.mcla.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), "TapOrHoldReleaseClientEvent", self, self.TapOrHoldReleaseClientEvent)

    # 电脑左键触发
    def LeftClickBeforeClientEvent(self, args):
        args['cancel'] = self.ClickEvent(True)

    # 电脑左键松开
    def LeftClickReleaseClientEvent(self, args):
        self.ClickEvent(False)

    # 触屏点击时触发
    def GetEntityByCoordEvent(self, args):
        # 排除准心模式下的触屏
        if not CF.CreatePlayerView(clientApi.GetLevelId()).GetToggleOption('SPLIT_CONTROLS') and clientApi.IsTouchWithMouse():
            self.ClickEvent(True)

    # 触屏松开事件
    def GetEntityByCoordReleaseClientEvent(self, args):
        if self.isHoldBefore:
            self.isHoldBefore = False
            self.UserEvent(False)
            return
        self.ClickEvent(False)

    # 触屏长按事件
    def HoldBeforeClientEvent(self, args):
        self.isHoldBefore = True
        args['cancel'] = self.UserEvent(True)

    # 鼠标右键事件
    def RightClickBeforeClientEvent(self, args):
        args['cancel'] = self.UserEvent(True)

    # 鼠标右键松开事件
    def RightClickReleaseClientEvent(self, args):
        self.UserEvent(False)

    # PCF11模式下，右键松开事件
    def TapOrHoldReleaseClientEvent(self, args):
        self.UserEvent(False)
        # 用于触屏时移动时可以继续点击屏幕
        if self.attack:
            self.ClickEvent(False, sava=False)

    # 攻击触发
    def ClickEvent(self, isdown, sava=True):
        if self.attack != isdown:
            if sava:
                self.attack = isdown
            return self.ClickEventBackFun(isdown, clientApi.IsTouchWithMouse())
        return False

    # 使用触发
    def UserEvent(self, isdown):
        if self.user != isdown:
            self.user = isdown
            return self.UserEventBackFun(isdown, clientApi.IsTouchWithMouse())
        return False


# 自定义选择框UI
class CusBoxUi(object):

    def __init__(self, mclass, UInode, createpath, boxpath, callback=None):
        # 客户端系统类，UI节点，创建路径，选择框路径，选中回调函数
        self.mcla = mclass
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        self.UInode = UInode
        """:type: mod.client.ui.screenNode.ScreenNode"""
        self.createpath = createpath
        self.boxpath = boxpath
        self.Tile = '请选择'
        self.callback = callback
        # [(显示名，数据， 图标路径)]
        self.datalist = []
        # 选择的数据的显示名
        self.seldata = None
        self.CreateUI()

    # 创建UI
    def CreateUI(self):

        self.UInode.GetBaseUIControl(self.boxpath + '/btns').asButton().AddTouchEventParams({"isSwallow": True})
        self.UInode.GetBaseUIControl(self.boxpath + '/btns').asButton().SetButtonTouchUpCallback(self.OnBoxBtnClick)

        if 'M_CUSBOX_PANEL' not in self.UInode.GetChildrenName(self.createpath):
            self.UInode.CreateChildControl('%s.M_CUSBOX_PANEL' % (CG.Ui_CommonName), 'M_CUSBOX_PANEL', self.UInode.GetBaseUIControl(self.createpath))

            setattr(self.UInode, '__CusBoxDataList__', [])

            @ViewBinder.binding(ViewBinder.BF_BindString, '#M_CUSBOX_PANEL_TITLE_TEXT')
            def _M_CUSBOX_PANEL_TITLE_TEXT(ui): return self.M_CUSBOX_PANEL_TITLE_TEXT()

            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#M_CUSBOX_PANEL_XX_BTN')
            def _M_CUSBOX_PANEL_XX_BTN(ui, args): self.M_CUSBOX_PANEL_XX_BTN(args)

            @ViewBinder.binding(ViewBinder.BF_BindInt, '#M_CUSBOX_GRID_ITEM_COUNT')
            def _M_CUSBOX_GRID_ITEM_COUNT(ui): return self.M_CUSBOX_GRID_ITEM_COUNT()

            @ViewBinder.binding(ViewBinder.ToggleFilter | ViewBinder.BF_ToggleChanged, '#M_CUSBOX_TOGGLE_NAME')
            def _M_CUSBOX_TOGGLE_NAME(ui, args): self.M_CUSBOX_TOGGLE_NAME(args)

            @ViewBinder.binding_collection(ViewBinder.BF_BindBool, 'M_CUSBOX_GRID_GRID_NAME', '#M_CUSBOX_TOGGLE_STATE')
            def _M_CUSBOX_TOGGLE_STATE(ui, index): return self.M_CUSBOX_TOGGLE_STATE(index)

            @ViewBinder.binding_collection(ViewBinder.BF_BindString, 'M_CUSBOX_GRID_GRID_NAME', '#M_CUSBOX_TOGGLE_ITEM_TEXT')
            def _M_CUSBOX_TOGGLE_ITEM_TEXT(ui, index): return self.M_CUSBOX_TOGGLE_ITEM_TEXT(index)

            @ViewBinder.binding_collection(ViewBinder.BF_BindString, 'M_CUSBOX_GRID_GRID_NAME', '#M_CUSBOX_TOGGLE_ITEM_ICON')
            def _M_CUSBOX_TOGGLE_ITEM_ICON(ui, index): return self.M_CUSBOX_TOGGLE_ITEM_ICON(index)

            M.CreateDynamicBind(self.UInode, _M_CUSBOX_PANEL_TITLE_TEXT)
            M.CreateDynamicBind(self.UInode, _M_CUSBOX_PANEL_XX_BTN)
            M.CreateDynamicBind(self.UInode, _M_CUSBOX_GRID_ITEM_COUNT)
            M.CreateDynamicBind(self.UInode, _M_CUSBOX_TOGGLE_NAME)
            M.CreateDynamicBind(self.UInode, _M_CUSBOX_TOGGLE_STATE)
            M.CreateDynamicBind(self.UInode, _M_CUSBOX_TOGGLE_ITEM_TEXT)
            M.CreateDynamicBind(self.UInode, _M_CUSBOX_TOGGLE_ITEM_ICON)

    # 显示选择列表
    def OnShow(self, datalist, title='请选择'):
        """
        dataList: [[显示名，数据， 图标路径]] or [['显示名']]
        title: 标题
        """
        self.datalist = copy.deepcopy(datalist)
        self.Tile = title

    # 设置按钮文本或依据按钮文本选择数据
    def SelectItem(self, name=None):
        if name:
            self.UInode.GetBaseUIControl(self.boxpath + '/btns/button_label').asLabel().SetText(name)
        else:
            name = self.UInode.GetBaseUIControl(self.boxpath + '/btns/button_label').asLabel().GetText()
            self.seldata = name

    # 获取选择的数据
    def GetSelectData(self):
        for _d in self.datalist:
            if M.get_element(_d, 0, None) == self.seldata:
                return _d

        return None

    # 清除选择数据
    def clearData(self):
        self.seldata = None
        self.UInode.GetBaseUIControl(self.boxpath + '/btns/button_label').asLabel().SetText('请选择')

    def OnBoxBtnClick(self, args):
        setattr(self.UInode, '__CusBoxDataList__', self.datalist)
        setattr(self.UInode, '__CusBoxData__', self)
        self.SelectItem()
        self.UInode.GetBaseUIControl(self.createpath + '/M_CUSBOX_PANEL').SetVisible(True, False)

    def M_CUSBOX_PANEL_TITLE_TEXT(self):
        try:
            return getattr(self.UInode, '__CusBoxData__', None).Tile
        except Exception:
            return '请选择'

    def M_CUSBOX_PANEL_XX_BTN(self, args):
        self.UInode.GetBaseUIControl(self.createpath + '/M_CUSBOX_PANEL').SetVisible(False, False)

    def M_CUSBOX_GRID_ITEM_COUNT(self):
        return len(getattr(self.UInode, '__CusBoxDataList__', []))

    def M_CUSBOX_TOGGLE_NAME(self, args):
        index = args['index']
        CusBoxDataList = getattr(self.UInode, '__CusBoxDataList__', [])
        CusBoxData = getattr(self.UInode, '__CusBoxData__', None)
        if CusBoxData:
            if CusBoxData.callback:
                CusBoxData.callback(CusBoxDataList[index])
            CusBoxData.seldata = M.get_element(CusBoxDataList[index], 0, None)
            CusBoxData.SelectItem(CusBoxData.seldata)
        self.M_CUSBOX_PANEL_XX_BTN(args)

    def M_CUSBOX_TOGGLE_STATE(self, index):
        try:
            CusBoxDataList = getattr(self.UInode, '__CusBoxDataList__', [])
            CusBoxData = getattr(self.UInode, '__CusBoxData__', None)
            if CusBoxData.seldata:
                if CusBoxData.seldata in CusBoxDataList[index]:
                    return True
                else:
                    return False
        except Exception:
            pass
        return False

    def M_CUSBOX_TOGGLE_ITEM_TEXT(self, index):
        try:
            return M.get_element(getattr(self.UInode, '__CusBoxDataList__', [])[index], 0, '')
        except Exception:
            pass

    def M_CUSBOX_TOGGLE_ITEM_ICON(self, index):
        try:
            _d = M.get_element(getattr(self.UInode, '__CusBoxDataList__', [])[index], 2, None)
            if _d:
                return _d
            else:
                return ''
        except Exception:
            pass


# 自定义数量选择器
class count_controls(object):

    def __init__(self, ui, createpath):
        self.createpath = createpath
        self.mui = ui
        """:type: mod.client.ui.screenNode.ScreenNode"""
        self._sumtext = '1'
        self._max = 100 + 1
        self.back = None
        self.mbpath = None

        self.state = True

        self.InitUiPanel()

    def InitUiPanel(self):
        if 'M_CountContPanel' not in self.mui.GetChildrenName(self.createpath):
            self.mui.CreateChildControl('%s.M_CountContPanel' % (CG.Ui_CommonName), 'M_CountContPanel', self.mui.GetBaseUIControl(self.createpath))

            self.mbpath = self.createpath + '/M_CountContPanel'

            setattr(self.mui, '__ContPanelClass__', self)

            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, "#count_cont_gn_btn")
            def _count_cont_gn_btn(ui, args): self.count_cont_gn_btn(args)

            @ViewBinder.binding(ViewBinder.BF_BindFloat, '#slider_value')
            def _slider_value(ui): return self.slider_value()

            @ViewBinder.binding(ViewBinder.BF_BindInt, '#slider_steps')
            def _slider_steps(ui): return self.slider_steps()

            @ViewBinder.binding(ViewBinder.BF_SliderChanged | ViewBinder.BF_SliderFinished, '#slider_state')
            def _slider_state(ui, v, f, _un): self.slider_state(v, f, _un)

            @ViewBinder.binding(ViewBinder.BF_BindString, '#count_cont_sum_text')
            def _count_cont_sum_text(ui): return self.count_cont_sum_text()

            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#count_conts_value_btn')
            def _count_conts_value_btn(ui, args): self.count_conts_value_btn(args)

            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#count_cont_clear_btn')
            def _count_cont_clear_btn(ui, args): self.count_cont_clear_btn(args)

            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#count_cont_mb_xx_btn')
            def _count_cont_mb_xx_btn(ui, args): self.count_cont_mb_xx_btn(args)

            M.CreateDynamicBind(self.mui, _count_cont_gn_btn)
            M.CreateDynamicBind(self.mui, _slider_value)
            M.CreateDynamicBind(self.mui, _slider_steps)
            M.CreateDynamicBind(self.mui, _slider_state)
            M.CreateDynamicBind(self.mui, _count_cont_sum_text)
            M.CreateDynamicBind(self.mui, _count_conts_value_btn)
            M.CreateDynamicBind(self.mui, _count_cont_clear_btn)
            M.CreateDynamicBind(self.mui, _count_cont_mb_xx_btn)

    def Open(self, maxs=100, back=None):
        # type: (int, any) -> None
        """打开界面"""
        self.state = True
        self._sumtext = '1.0'
        self._max = maxs + 1
        self.back = back
        self.mui.GetBaseUIControl(self.mbpath).SetVisible(True, False)

    def count_cont_gn_btn(self, args):
        ButtonPath = args['ButtonPath']
        _ids = ButtonPath[-15:]
        _d = filter(str.isdigit, _ids)
        if _d:
            # print int(_d)
            if self.state:
                self._sumtext = str(min(int(_d), self._max - 1))
                self.state = False
                self.mui.UpdateScreen()
            else:
                self._sumtext = str(min(int(str(int(float(self._sumtext))) + _d), self._max - 1))
                self.mui.UpdateScreen()
            # print '是数字'
        else:
            if _ids.count('count_conts_qr'):
                if int(float(self._sumtext)) <= 0:
                    pass
                    # print '错误，最小不能为0'
                else:
                    self.back(int(float(self._sumtext)))
                    self.count_cont_mb_xx_btn({})
            elif _ids.count('count_conts_min'):
                self._sumtext = '1'
                self.mui.UpdateScreen()
            elif _ids.count('count_conts_max'):
                self._sumtext = str(self._max - 1)
                self.mui.UpdateScreen()

    def slider_value(self):
        return float(float(self._sumtext) / self._max)

    def slider_steps(self):
        return 1.0

    def slider_state(self, v, f, _un):
        self._sumtext = str(min(self._max * v, self._max - 1))
        if f:
            self.state = True
        # print v, f, _un

    def Update(self):
        pass
        # print '111'

    def count_cont_sum_text(self):
        return str(int(float(self._sumtext)))

    def count_conts_value_btn(self, args):
        ButtonPath = args['ButtonPath']
        _ids = ButtonPath[-30:]
        if _ids.count('count_conts_add'):
            self._sumtext = str(float(min(int(float(self._sumtext)) + 1, self._max - 1)))
            self.state = True
        else:
            self._sumtext = str(float(max(int(float(self._sumtext)) - 1, 1)))
            self.state = True
        self.mui.UpdateScreen()

    def count_cont_clear_btn(self, args):
        if len(str(int(float(self._sumtext)))) <= 1:
            self._sumtext = '1'
            self.state = True
        else:
            self._sumtext = str(float(str(int(float(self._sumtext)))[:-1]))
        self.mui.UpdateScreen()

    def count_cont_mb_xx_btn(self, args):
        self.mui.GetBaseUIControl(self.mbpath).SetVisible(False, False)

    def __del__(self):
        print '删除数量输入实例'


# 内嵌物品选择面板（全自动注册，参考 count_controls 模式）
class ItemPicker(object):

    def __init__(self, ui, createpath, mclass):
        self.mui = ui
        """:type: mod.client.ui.screenNode.ScreenNode"""
        self.createpath = createpath
        self.mclass = mclass
        """:type: custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"""
        self.selitemsdata = {'bbtype': 0, 'xzid': None, 'itemslist': []}
        self.back = None

        self.InitUiPanel()

    def InitUiPanel(self):
        if 'item_xz_panel' not in self.mui.GetChildrenName(self.createpath):
            self.mui.CreateChildControl('%s.item_xz_panel' % (CG.Ui_CommonName), 'item_xz_panel',
                                        self.mui.GetBaseUIControl(self.createpath))
            self.mbpath = self.createpath + '/item_xz_panel'

            setattr(self.mui, '__ItemPickerClass__', self)

            # 模式切换
            @ViewBinder.binding(ViewBinder.ToggleFilter | ViewBinder.BF_ToggleChanged, '#item_xz_type_toggle_jh')
            def _item_xz_type_toggle_jh(ui, args): self.item_xz_type_toggle_jh(args)
            @ViewBinder.binding(ViewBinder.BF_BindBool, '#item_xz_type_toggle_nr_0')
            def _item_xz_type_toggle_nr_0(ui): return self.item_xz_type_toggle_nr_0()
            @ViewBinder.binding(ViewBinder.BF_BindBool, '#item_xz_type_toggle_nr_1')
            def _item_xz_type_toggle_nr_1(ui): return self.item_xz_type_toggle_nr_1()
            @ViewBinder.binding(ViewBinder.BF_BindBool, '#item_xz_type_toggle_nr_2')
            def _item_xz_type_toggle_nr_2(ui): return self.item_xz_type_toggle_nr_2()

            # 翻页
            @ViewBinder.binding(ViewBinder.BF_BindString, '#item_xz_yei_text')
            def _item_xz_yei_text(ui): return self.item_xz_yei_text()
            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#item_xz_next_btn')
            def _item_xz_next_btn(ui, args): self.item_xz_next_btn(args)
            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#item_xz_notnext_btn')
            def _item_xz_notnext_btn(ui, args): self.item_xz_notnext_btn(args)

            # 搜索
            @ViewBinder.binding(ViewBinder.BF_EditChanged | ViewBinder.BF_EditFinished, '#item_xz_sous_edit_jh')
            def _item_xz_sous_edit_jh(ui, args): self.item_xz_sous_edit_jh(args)
            @ViewBinder.binding(ViewBinder.BF_BindString, '#item_xz_sous_edit_nr')
            def _item_xz_sous_edit_nr(ui): return self.item_xz_sous_edit_nr()

            # 物品网格
            @ViewBinder.binding_collection(ViewBinder.BF_BindInt, 'items_list_grid', '#items_id_aux')
            def _items_id_aux(ui, index): return self.items_id_aux(index)
            @ViewBinder.binding_collection(ViewBinder.BF_BindInt, 'items_list_grid', '#items_custom_color')
            def _items_custom_color(ui, index): return self.items_custom_color(index)
            @ViewBinder.binding_collection(ViewBinder.BF_BindString, 'items_list_grid', '#items_trim_materialr')
            def _items_trim_materialr(ui, index): return self.items_trim_materialr(index)
            @ViewBinder.binding(ViewBinder.ToggleFilter | ViewBinder.BF_ToggleChanged, '#selitems_iitems_toggle_jh')
            def _selitems_iitems_toggle_jh(ui, args): self.selitems_iitems_toggle_jh(args)
            @ViewBinder.binding_collection(ViewBinder.BF_BindBool, 'items_list_grid', '#selitems_iitems_toggle_nr')
            def _selitems_iitems_toggle_nr(ui, index): return self.selitems_iitems_toggle_nr(index)

            # 确认/取消
            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#item_xz_qr_btn')
            def _item_xz_qr_btn(ui, args): self.item_xz_qr_btn(args)
            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#item_xz_qx_btn')
            def _item_xz_qx_btn(ui, args): self.item_xz_qx_btn(args)

            # 注册所有动态绑定
            for _f in [_item_xz_type_toggle_jh, _item_xz_type_toggle_nr_0, _item_xz_type_toggle_nr_1,
                       _item_xz_type_toggle_nr_2, _item_xz_yei_text, _item_xz_next_btn,
                       _item_xz_notnext_btn, _item_xz_sous_edit_jh, _item_xz_sous_edit_nr,
                       _items_id_aux, _items_custom_color, _items_trim_materialr,
                       _selitems_iitems_toggle_jh, _selitems_iitems_toggle_nr,
                       _item_xz_qr_btn, _item_xz_qx_btn]:
                M.CreateDynamicBind(self.mui, _f)

    # =========================== 打开/关闭 ===========================

    def Open(self, bbtype=0, back=None):
        """打开物品选择面板"""
        sorter = self.mclass.JEIStyleSorterClass
        if not sorter:
            self.mclass.ShowTipsPanel('物品数据加载中，请稍后...')
            return
        self.selitemsdata['bbtype'] = bbtype
        self.selitemsdata['xzid'] = None
        self.selitemsdata['itemslist'] = sorter.current_items
        self.back = back
        self.mui.GetBaseUIControl(self.mbpath).SetVisible(True, False)

    def Close(self):
        self.mui.GetBaseUIControl(self.mbpath).SetVisible(False, False)

    # =========================== 模式切换 ===========================

    def item_xz_type_toggle_jh(self, args):
        index = args['index']
        sorter = self.mclass.JEIStyleSorterClass
        if not sorter:
            return ViewRequest.Refresh
        if index == 0:
            sorter.set_to_normal_mode()
        elif index == 1:
            sorter.set_to_backpack_mode()
        elif index == 2:
            self.mclass.ShowTipsPanel('未联动RPG组件，不可使用!')
            return ViewRequest.Refresh
        self.selitemsdata['bbtype'] = index
        self.selitemsdata['xzid'] = None
        self.selitemsdata['itemslist'] = sorter.current_items

    def item_xz_type_toggle_nr_0(self):
        if not self.mclass.JEIStyleSorterClass:
            return True
        return not self.mclass.JEIStyleSorterClass.get_current_state().get('is_backpack_mode')

    def item_xz_type_toggle_nr_1(self):
        if not self.mclass.JEIStyleSorterClass:
            return False
        return self.mclass.JEIStyleSorterClass.get_current_state().get('is_backpack_mode')

    def item_xz_type_toggle_nr_2(self):
        return self.selitemsdata.get('bbtype') == 2

    # =========================== 翻页 ===========================

    def item_xz_yei_text(self):
        if self.mclass.JEIStyleSorterClass:
            return self.mclass.JEIStyleSorterClass.page_info
        return '0/0'

    def item_xz_next_btn(self, args):
        if self.mclass.JEIStyleSorterClass:
            self.selitemsdata['itemslist'] = self.mclass.JEIStyleSorterClass.next_page()
            self.selitemsdata['xzid'] = None
        return ViewRequest.Refresh

    def item_xz_notnext_btn(self, args):
        if self.mclass.JEIStyleSorterClass:
            self.selitemsdata['itemslist'] = self.mclass.JEIStyleSorterClass.prev_page()
            self.selitemsdata['xzid'] = None
        return ViewRequest.Refresh

    # =========================== 搜索 ===========================

    def item_xz_sous_edit_jh(self, args):
        sorter = self.mclass.JEIStyleSorterClass
        if sorter:
            sorter.search_term = args['Text']
            self.selitemsdata['itemslist'] = sorter.search()
            self.selitemsdata['xzid'] = None
        return ViewRequest.Refresh

    def item_xz_sous_edit_nr(self):
        if self.mclass.JEIStyleSorterClass:
            return self.mclass.JEIStyleSorterClass.search_term
        return ''

    # =========================== 物品网格 ===========================

    def items_id_aux(self, index):
        try:
            return self.selitemsdata['itemslist'][index][1]['idaux']
        except Exception:
            return 0

    def items_custom_color(self, index):
        try:
            return self.selitemsdata['itemslist'][index][1].get('customColor', 0)
        except Exception:
            return -1

    def items_trim_materialr(self, index):
        try:
            return self.selitemsdata['itemslist'][index][1].get('Trim', '')
        except Exception:
            return ''

    def selitems_iitems_toggle_jh(self, args):
        index = args['index']
        if len(self.selitemsdata['itemslist']) <= index:
            return ViewRequest.Refresh
        self.selitemsdata['xzid'] = index
        return ViewRequest.Refresh

    def selitems_iitems_toggle_nr(self, index):
        return self.selitemsdata.get('xzid') == index

    # =========================== 确认/取消 ===========================

    def item_xz_qr_btn(self, args):
        xzid = self.selitemsdata.get('xzid')
        if isinstance(xzid, int) and 0 <= xzid < len(self.selitemsdata['itemslist']):
            itemsdata = self.selitemsdata['itemslist'][xzid]
            item_dict = M.CreateItems(itemsdata[0])
            item_info = itemsdata[1]
            self.Close()
            if self.back:
                self.back(item_dict, item_info)
            return ViewRequest.Refresh
        else:
            self.mclass.ShowTipsPanel('请选择物品!')

    def item_xz_qx_btn(self, args):
        self.Close()


# 颜色选择面板（HSB 色板 + 滑块 + RGB 输入）
class ColorPicker(object):

    def __init__(self, ui, createpath, mclass):
        self.mui = ui
        """:type: mod.client.ui.screenNode.ScreenNode"""
        self.createpath = createpath
        self.mclass = mclass
        self.back = None
        self.rgb = (1.0, 0.0, 0.0)
        self.color_h, self.color_s, self.color_b = M.RGB2HSB(*self.rgb)
        self.TouchPosCache = (0.0, 0.0)

        self.InitUiPanel()

    def InitUiPanel(self):
        if 'M_ColorPickerPanel' not in self.mui.GetChildrenName(self.createpath):
            self.mui.CreateChildControl('%s.M_ColorPickerPanel' % (CG.Ui_CommonName),
                                        'M_ColorPickerPanel', self.mui.GetBaseUIControl(self.createpath))
            self.mbpath = self.createpath + '/M_ColorPickerPanel'
            setattr(self.mui, '__ColorPickerClass__', self)

            # Get UI controls
            self.palette_body = self.mui.GetBaseUIControl(
                self.mbpath + '/content/palette_main_body/color_blend/color_gradient_rgb').asImage()
            self.selector = self.mui.GetBaseUIControl(
                self.mbpath + '/content/palette_main_body/btn_color_selector').asImage()
            self.slider = self.mui.GetBaseUIControl(
                self.mbpath + '/content/palette_slider').asSlider()
            self.color_show = self.mui.GetBaseUIControl(
                self.mbpath + '/content/color_show_img').asImage()
            self.edit_r = self.mui.GetBaseUIControl(
                self.mbpath + '/content/show_and_edit/R_label/text_edit_box').asTextEditBox()
            self.edit_g = self.mui.GetBaseUIControl(
                self.mbpath + '/content/show_and_edit/G_label/text_edit_box').asTextEditBox()
            self.edit_b = self.mui.GetBaseUIControl(
                self.mbpath + '/content/show_and_edit/B_label/text_edit_box').asTextEditBox()

            # Touch handling on palette body
            body_btn = self.mui.GetBaseUIControl(self.mbpath + '/content/palette_main_body').asButton()
            body_btn.AddTouchEventParams()
            body_btn.SetButtonTouchMoveCallback(self._OnPaletteTouchMove)
            body_btn.SetButtonTouchDownCallback(self._OnPaletteTouchDown)

            # Bindings
            @ViewBinder.binding(ViewBinder.BF_EditChanged | ViewBinder.BF_EditFinished, "#RCM_SDK_PALETTE_EDIT_BOX")
            def _BindPaletteEditBox(ui, args): self._UpdateTextEdit()
            @ViewBinder.binding(ViewBinder.BF_SliderChanged | ViewBinder.BF_SliderFinished, "#RCM_SDK_PALETTE_SLIDER")
            def _BindPaletteSlider(ui, args): self._UpdateSlider()
            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#sel_color_qr_btn')
            def _sel_color_qr_btn(ui, args): self.sel_color_qr_btn(args)
            @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, '#sel_color_qx_btn')
            def _sel_color_qx_btn(ui, args): self.Close()

            M.CreateDynamicBind(self.mui, _BindPaletteEditBox)
            M.CreateDynamicBind(self.mui, _BindPaletteSlider)
            M.CreateDynamicBind(self.mui, _sel_color_qr_btn)
            M.CreateDynamicBind(self.mui, _sel_color_qx_btn)

    # =========================== 打开/关闭 ===========================

    def Open(self, back=None, color=None):
        """打开颜色面板。color: "R,G,B" 字符串如 '1.0,0.5,0.0'，不传默认红色"""
        self.back = back
        if color:
            try:
                parts = color.split(',')
                self.rgb = tuple(float(p) for p in parts[:3])
            except Exception:
                self.rgb = (1.0, 0.0, 0.0)
        else:
            self.rgb = (1.0, 0.0, 0.0)
        self.color_h, self.color_s, self.color_b = M.RGB2HSB(*self.rgb)
        self._UpdataColorShow()
        self.mui.GetBaseUIControl(self.mbpath).SetVisible(True, False)

    def Close(self):
        self.mui.GetBaseUIControl(self.mbpath).SetVisible(False, False)

    # =========================== 触摸回调 ===========================

    def _OnPaletteTouchDown(self, args):
        pos = self.mui.GetGlobalPosition(self.mbpath + '/content/palette_main_body')
        size = self.mui.GetBaseUIControl(self.mbpath + '/content/palette_main_body').GetSize()
        sel_size = self.selector.GetSize()
        self._pal_pos = pos
        self._pal_size = size
        self._sel_size = sel_size
        self._OnPaletteTouchMove(args)

    def _OnPaletteTouchMove(self, args):
        if not hasattr(self, '_pal_pos'): return
        touch = [args["TouchPosX"], args["TouchPosY"]]
        self.color_s = self._limit((touch[0] - self._pal_pos[0]) / self._pal_size[0], 0, 1)
        self.color_b = 1.0 - self._limit((touch[1] - self._pal_pos[1]) / self._pal_size[1], 0, 1)
        self._UpdataColorShow()

    # =========================== 滑块/输入框 ===========================

    def _UpdateSlider(self):
        pro = self.slider.GetSliderValue()
        if pro > 0.01:
            self.color_h = 360.0 * (1.0 - pro)
        self._UpdataColorShow()

    def _UpdateTextEdit(self):
        rgb = list(self.rgb)
        for i, edit in enumerate((self.edit_r, self.edit_g, self.edit_b)):
            text = edit.GetEditText() or "0"
            text = self._limitInt(text)
            v = int(text)
            if v <= 255 and v != int(self.rgb[i] * 255):
                rgb[i] = v / 255.0
        self.color_h, self.color_s, self.color_b = M.RGB2HSB(*rgb)
        self._UpdataColorShow(tuple(rgb))

    # =========================== 确认/取消 ===========================

    def sel_color_qr_btn(self, args):
        s = "%.4f,%.4f,%.4f" % (round(self.rgb[0], 4), round(self.rgb[1], 4), round(self.rgb[2], 4))
        self.Close()
        if self.back:
            self.back(s)

    # =========================== 更新显示 ===========================

    def _UpdataColorShow(self, rgb=None):
        if not rgb:
            self.rgb = M._HSB2RGB(self.color_h, self.color_s, self.color_b)
        else:
            self.rgb = rgb
        self.palette_body.SetSpriteColor(M._HSB2RGB(self.color_h, 1.0, 1.0))
        self.color_show.SetSpriteColor(self.rgb)
        pos_x = self.color_s * self._pal_size[0] - self._sel_size[0] / 2.0
        pos_y = (1.0 - self.color_b) * self._pal_size[1] - self._sel_size[1] / 2.0
        self.selector.SetPosition((pos_x, pos_y))
        if 35 < self.color_h < 200 and self.color_b > 0.5:
            self.selector.SetSpriteColor((0, 0, 0))
        else:
            self.selector.SetSpriteColor((1, 1, 1))
        self.slider.SetSliderValue(1.0 - self.color_h / 360.0)
        self.edit_r.SetEditText(str(int(self.rgb[0] * 255)))
        self.edit_g.SetEditText(str(int(self.rgb[1] * 255)))
        self.edit_b.SetEditText(str(int(self.rgb[2] * 255)))

    @staticmethod
    def _limit(x, a, b):
        return max(min(x, b), a)

    @staticmethod
    def _limitInt(text):
        text = "".join(x if x.isdigit() else "" for x in text)
        return text if text.isdigit() else "0"
