
# -*- coding: utf-8 -*-

import mod.server.extraServerApi as serverApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

from custom_warehouseScripts.custom_warehouseServerSystem.custom_warehouseServerSystem import custom_warehouseServerSystem as mserverSystem

ServerSystem = serverApi.GetServerSystemCls()
CF = serverApi.GetEngineCompFactory()
LevelID = serverApi.GetLevelId()
ME = serverApi.GetMinecraftEnum()


class AnyEvent(object):

    def __init__(self, server_system):
        # type: (mserverSystem) -> None
        self._Mser = server_system
        """:type: custom_warehouseScripts.custom_warehouseServerSystem.custom_warehouseServerSystem.custom_warehouseServerSystem"""

    def AnyEvent(self, args):
        playerid = args['__id__']
        # 含 backdata 表示这是客户端对“服务端发起请求”的回调响应，派发到服务端暂存函数
        if 'backdata' in args:
            self._Mser.OnClientBack(args)
            return
        # 否则为客户端发起的请求，按 lx 路由处理并回传结果
        back = args.get('back', None)
        data = args['data']
        backdata = getattr(self, data['lx'])(playerid, data)
        if back:
            self._Mser.NotifyToClient(playerid, 'AnyEvent', {'back': back, 'backdata': backdata})

    def GetPlayerPermission(self, playerid, data):
        """客户端获取玩家权限"""
        _d = {
            'isop': False
        }
        _d['isop'] = True if CF.CreatePlayer(playerid).GetPlayerOperation() == 2 else False
        return _d

    def getallitems(self, playerid, data):
        """客户端请求全部物品列表（物品选择器用）"""
        return {'itemslist': CF.CreateItem(LevelID).GetLoadItems(True)}

    def getallentitystrid(self, playerid, data):
        """客户端请求全部实体列表"""
        return {'enstridlist': CF.CreateGame(LevelID).GetLoadActors()}

    # -------------------------------------- 跨存档数据 --------------------------------------

    def _IsAdmin(self, playerid):
        """判断玩家是否为 OP（跨存档操作需要管理员权限）"""
        return CF.CreatePlayer(playerid).GetPlayerOperation() == 2

    def getworlddatakeys(self, playerid, data):
        """返回跨存档需要迁移的数据 key 列表。
        客户端 worlddata_screen 用此列表逐 key 请求/写入。
        默认迁移：主数据（KV_KEY_MAIN）+ 全局配置（KV_KEY_GLOBAL_CONFIG）。
        按需在此列表中增删 key 即可扩展迁移范围。"""
        return {'keys': [CG.KV_KEY_MAIN, CG.KV_KEY_GLOBAL_CONFIG]}

    # getworlddatakeys: 声明跨存档迁移的数据 key 列表

    def GetWorldData(self, playerid, data):
        """跨存档-导出：按 key 从服务端读取数据返回给客户端
        key 为 KV_KEY_MAIN → 主数据；KV_KEY_GLOBAL_CONFIG → 全局配置"""
        if not self._IsAdmin(playerid):
            return {'state': False, 'msg': '无权限（需要 OP）'}
        key = (data or {}).get('key', '')
        result = None
        if key == CG.KV_KEY_MAIN:
            result = self._Mser.ContData.xxxdata
        elif key == CG.KV_KEY_GLOBAL_CONFIG:
            result = self._Mser.GlobalConfig.data
        return {'key': key, 'data': result}

    # GetWorldData: 按 key 返回服务端主数据或全局配置（跨存档导出阶段）

    def SetWorldData(self, playerid, data):
        """跨存档-导入：按 key 将客户端数据写入服务端；特殊 key 触发备份/收尾
        - 普通_key：覆盖服务端对应数据
        - __BackUp__：导入前深拷贝备份（便于超时还原）
        - __BackUpEnd__：导入完成后落盘主数据 + 全局配置"""
        if not self._IsAdmin(playerid):
            return {'state': False, 'msg': '无权限（需要 OP）'}
        key = (data or {}).get('key', '')
        val = (data or {}).get('data')
        if val:
            if key == CG.KV_KEY_MAIN:
                self._Mser.ContData.xxxdata = val
            elif key == CG.KV_KEY_GLOBAL_CONFIG:
                self._Mser.GlobalConfig.data = val
        if key == '__BackUp__':
            self._Mser.ContData.BackUpData(True)
        elif key == '__BackUpEnd__':
            # 强制落盘主数据
            self._Mser.ContData._dirty = True
            self._Mser.ContData.FlushSave()
            # 落盘全局配置
            try:
                gcfg = self._Mser.GlobalConfig
                gcfg.compdata.SetExtraData(CG.KV_KEY_GLOBAL_CONFIG, gcfg.data, False)
                gcfg.compdata.SaveExtraData()
            except Exception as e:
                print '[ModName] 跨存档 GlobalConfig 落盘失败:', e
        return {'key': key, 'data': None}

    # SetWorldData: 按 key 写入服务端；__BackUp__=深拷贝备份，__BackUpEnd__=落盘+保存

    def BackWorldData(self, playerid, data):
        """跨存档-还原：超时时从备份还原服务端主数据"""
        if not self._IsAdmin(playerid):
            return {'state': False, 'msg': '无权限（需要 OP）'}
        self._Mser.ContData.BackUpData(False)
        return {'state': True}

    # BackWorldData: 从 _BackUpData 还原主数据（超时保护）
