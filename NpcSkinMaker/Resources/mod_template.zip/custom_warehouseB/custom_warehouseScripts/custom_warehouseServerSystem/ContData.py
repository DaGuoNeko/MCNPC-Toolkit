# -*- coding: utf-8 -*-
"""存档数据管理器：统一管理 ExtraData 读写、节流保存、初始化。

典型工作流：
1. __init__ → InitData() 从 ExtraData 加载或初始化
2. 业务代码修改 self.xxxdata 后调用 QusetUpExtraData(key) 标记脏数据
3. 定时器/退服时调用 SaveData() 或 FlushSave() 落盘
4. 退服时调用 FlushSave() 强制立即保存（不走节流）
"""

import copy
import time

import mod.server.extraServerApi as serverApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

ServerSystem = serverApi.GetServerSystemCls()
CF = serverApi.GetEngineCompFactory()
LevelID = serverApi.GetLevelId()
ME = serverApi.GetMinecraftEnum()


class ContData(object):

    def __init__(self, server_system):
        self.compdata = CF.CreateExtraData(LevelID)
        self._Mser = server_system
        """:type: custom_warehouseScripts.custom_warehouseServerSystem.custom_warehouseServerSystem.custom_warehouseServerSystem"""

        # 主数据结构
        self.xxxdata = {}

        self.InitData()

        # 节流保存时间表：key → 下次保存时间戳
        self.savalogs = {}
        # 脏数据标记：节流窗口内快速判断是否有待保存数据
        self._dirty = False
        # 节流定时器句柄
        self._throttle_timer = None

        # 启动节流检查定时器
        CF.CreateGame(LevelID).AddRepeatedTimer(CG.SAVE_TIMER_INTERVAL, self._ThrottleCheck)

    # =========================== 数据加载 / 保存 ===========================

    def InitData(self):
        """加载/初始化存档数据：从 ExtraData 读；缺失则初始化骨架并落盘"""
        xxxdata = self.compdata.GetExtraData(CG.KV_KEY_MAIN)
        if xxxdata is None:
            print '[ModName] 初始化数据'
            self.compdata.SetExtraData(CG.KV_KEY_MAIN, self.xxxdata, False)
            self.compdata.SaveExtraData()
        else:
            print '[ModName] 加载数据'
            self.xxxdata = xxxdata

    def SaveData(self):
        """落盘主数据到 ExtraData"""
        try:
            self.compdata.SetExtraData(CG.KV_KEY_MAIN, self.xxxdata, False)
            self.compdata.SaveExtraData()
        except Exception as e:
            print '[ModName] SaveData 失败:', e

    def FlushSave(self):
        """强制立即保存（退服时调用，不走节流）"""
        if self._throttle_timer:
            try:
                CF.CreateGame(LevelID).CancelTimer(self._throttle_timer)
            except Exception:
                pass
            self._throttle_timer = None
        if self._dirty:
            self.SaveData()
            self._dirty = False
            self.savalogs.clear()

    # =========================== 节流保存 ===========================

    def QusetUpExtraData(self, key='ALL'):
        """标记脏数据并启动节流定时器"""
        now = time.time()
        self.savalogs[key] = now + CG.SAVE_THROTTLE_SECONDS
        self._dirty = True
        if self._throttle_timer is None:
            try:
                self._throttle_timer = CF.CreateGame(LevelID).AddTimer(
                    CG.SAVE_THROTTLE_SECONDS, self._DoThrottledSave)
            except Exception:
                self._DoThrottledSave()

    def _ThrottleCheck(self):
        """定时器检查：所有 key 超时则保存"""
        if not self._dirty:
            return
        now = time.time()
        if all(t <= now for t in self.savalogs.values()):
            self._DoThrottledSave()

    def _DoThrottledSave(self):
        """执行节流落盘"""
        self._throttle_timer = None
        self.SaveData()
        self._dirty = False
        self.savalogs.clear()

    # =========================== 跨存档备份/还原 ===========================

    def BackUpData(self, isbackup=False):
        """跨存档覆盖前的临时深拷贝备份 / 超时还原
        :param isbackup: True=深拷贝当前 xxxdata 到 _BackUpData；False=从 _BackUpData 还原
        用途：worlddata_screen 导入数据前先备份，超时或异常时还原
        """
        if isbackup:
            self._BackUpData = copy.deepcopy(self.xxxdata)
        else:
            if getattr(self, '_BackUpData', None):
                self.xxxdata = self._BackUpData
                self.QusetUpExtraData()
    # BackUpData: 跨存档覆盖前深拷贝备份；超时时还原
