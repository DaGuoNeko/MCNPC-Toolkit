
# -*- coding: utf-8 -*-
"""自定义命令处理模块

命令声明文件位于行为包 netease_commands/ 目录下，每个 JSON 对应一个命令。
Python 端通过 cmdlist 字典路由：{命令全名: 处理函数}

统一处理函数签名：
    def handler(self, args, origin, return_failed, return_msg_key, variant):
        ...
        return return_failed, return_msg_key

参数说明：
    args: list — 命令参数列表（按 netease_commands JSON 中 args 顺序）
    origin: dict — 命令来源信息（含 entityId 等）
    return_failed: bool — 是否标记命令执行失败
    return_msg_key: str — 失败时显示的消息 key
    variant: str — 命令变体
"""

import mod.server.extraServerApi as serverApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

from custom_warehouseScripts.custom_warehouseServerSystem.custom_warehouseServerSystem import custom_warehouseServerSystem as mserverSystem

ServerSystem = serverApi.GetServerSystemCls()
CF = serverApi.GetEngineCompFactory()
LevelID = serverApi.GetLevelId()
ME = serverApi.GetMinecraftEnum()


class CustomCmd(object):

    def __init__(self, server_system):
        # type: (mserverSystem) -> None
        self._Mser = server_system
        """:type: custom_warehouseScripts.custom_warehouseServerSystem.custom_warehouseServerSystem.custom_warehouseServerSystem"""
        # 注册命令：{命令全名: 处理函数}
        self.cmdlist = {
            'cw:openui': self.openui,
            'cw:msg': self.msg,
        }

    def CustomCmdEvent(self, data):
        """命令事件统一入口，由 ListenEvents 注册的回调触发。"""
        command = data['command']
        args = data['args']
        origin = data['origin']
        variant = data['variant']
        if command in self.cmdlist:
            data['return_failed'], data['return_msg_key'] = self.cmdlist[command](args, origin, data['return_failed'], data['return_msg_key'], variant)

    # =========================== 命令处理函数 ===========================

    def openui(self, args, origin, return_failed, return_msg_key, variant):
        """cw:openui <目标> — 通知目标玩家客户端打开主界面。
        args[0]: 目标选择器解析出的玩家 entityId 列表"""
        try:
            player_ids = args[0] if args else []
            if not player_ids:
                return_failed = True
                return_msg_key = '未指定目标玩家'
                return return_failed, return_msg_key
            # 通知客户端打开界面（通过通用 TC 消息机制）
            for playerid in player_ids:
                self._Mser.NotifyToClient(playerid, 'AnyEvent', {
                    'data': {'lx': 'open_ui'}
                })
        except Exception:
            return_failed = True
            return_msg_key = '执行异常'
        return return_failed, return_msg_key

    def msg(self, args, origin, return_failed, return_msg_key, variant):
        """cw:msg <目标> <消息内容> — 向目标玩家发送聊天栏消息。
        args[0]: 目标选择器解析出的玩家 entityId 列表
        args[1]: 消息文本"""
        try:
            player_ids = args[0] if len(args) > 0 else []
            text = args[1] if len(args) > 1 else ''
            if not player_ids:
                return_failed = True
                return_msg_key = '未指定目标玩家'
                return return_failed, return_msg_key
            comp = CF.CreateGame(LevelID)
            for playerid in player_ids:
                comp.SetCommandResultMsg(playerid, text)
        except Exception:
            return_failed = True
            return_msg_key = '执行异常'
        return return_failed, return_msg_key
