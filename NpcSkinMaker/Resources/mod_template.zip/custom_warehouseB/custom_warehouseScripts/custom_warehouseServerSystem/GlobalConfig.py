# -*- coding: utf-8 -*-
"""全局动态配置管理器：独立的 ExtraData 表，供 OP 在线修改。

特点：
- 与主数据独立的 ExtraData 键（KV_KEY_GLOBAL_CONFIG）
- 设置后立即落盘（不走节流，管理员操作罕见但珍贵）
- DEFAULTS 定义所有可配置项及其默认值
- _Validate 对每个 key 做类型/范围校验

数据结构：
{
    'schema_version': 1,
    'config': {
        'example_key': 'value'
    }
}
"""

import mod.server.extraServerApi as serverApi
import custom_warehouseScripts.miao_Config as CG

CF = serverApi.GetEngineCompFactory()
LevelID = serverApi.GetLevelId()


class GlobalConfig(object):
    # 默认值表（key → 默认值）；未在 ExtraData 中显式设置时返回这里的值
    DEFAULTS = {
        # 'example_config_key': 'default_value',
    }

    def __init__(self, server_system):
        self._Mser = server_system
        """:type: custom_warehouseScripts.custom_warehouseServerSystem.custom_warehouseServerSystem.custom_warehouseServerSystem"""
        self.compdata = CF.CreateExtraData(LevelID)
        self.data = self._LoadOrInit()

    # =========================== 数据加载 ===========================

    def _LoadOrInit(self):
        """从 ExtraData 加载配置；缺失则初始化空骨架并落盘"""
        try:
            v = self.compdata.GetExtraData(CG.KV_KEY_GLOBAL_CONFIG)
        except Exception as e:
            print '[ModName][GlobalConfig] 读取异常:', e
            v = None
        if not v or not isinstance(v, dict):
            v = {'schema_version': 1, 'config': {}}
            try:
                self.compdata.SetExtraData(CG.KV_KEY_GLOBAL_CONFIG, v, False)
                self.compdata.SaveExtraData()
            except Exception as e:
                print '[ModName][GlobalConfig] 初始化落盘失败:', e
            return v
        v.setdefault('schema_version', 1)
        v.setdefault('config', {})
        return v

    # =========================== 校验 ===========================

    def _Validate(self, key, value):
        """字段验证：返回 (ok, normalized_value, err_msg)
        在此为每个 key 添加类型检查与范围限制
        """
        # 示例：
        # if key == 'max_example':
        #     try: v = int(value)
        #     except: return False, None, '必须是整数'
        #     if v < 1: return False, None, '不能小于1'
        #     return True, v, ''
        return True, value, ''

    # =========================== 读写接口 ===========================

    def Get(self, key):
        """读单项配置：优先持久化值 → DEFAULTS 默认值 → None"""
        config = self.data.get('config', {})
        if key in config:
            return config[key]
        return self.DEFAULTS.get(key)

    def GetAll(self):
        """读全部配置：DEFAULTS 打底 + 持久化覆盖"""
        result = dict(self.DEFAULTS)
        result.update(self.data.get('config', {}))
        return result

    def Set(self, key, value):
        """修改单项配置：校验 → 写内存 → 立即落盘
        :return: (ok: bool, msg: str)
        """
        if key not in self.DEFAULTS:
            return False, '未知配置项: %s' % key
        ok, normalized, err = self._Validate(key, value)
        if not ok:
            return False, err or '校验失败'
        config = self.data.setdefault('config', {})
        config[key] = normalized
        try:
            self.compdata.SetExtraData(CG.KV_KEY_GLOBAL_CONFIG, self.data, False)
            self.compdata.SaveExtraData()
        except Exception as e:
            return False, '落盘失败: %s' % e
        return True, ''

    def Reset(self, key):
        """重置单项配置为默认值（移除持久化覆盖）
        :return: (ok: bool, msg: str)
        """
        config = self.data.get('config', {})
        if key in config:
            del config[key]
        try:
            self.compdata.SetExtraData(CG.KV_KEY_GLOBAL_CONFIG, self.data, False)
            self.compdata.SaveExtraData()
        except Exception as e:
            return False, '落盘失败: %s' % e
        return True, ''
