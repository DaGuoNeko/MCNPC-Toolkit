# -*- coding: utf-8 -*-

import time
import uuid

import mod.server.extraServerApi as serverApi
import custom_warehouseScripts.miao_lid as M
import custom_warehouseScripts.miao_Config as CG

ServerSystem = serverApi.GetServerSystemCls()
CF = serverApi.GetEngineCompFactory()
LevelID = serverApi.GetLevelId()
ME = serverApi.GetMinecraftEnum()


class custom_warehouseServerSystem(ServerSystem):
    def __init__(self, namespace, systemName):
        ServerSystem.__init__(self, namespace, systemName)
        import custom_warehouseScripts.custom_warehouseServerSystem.AnyEvent as AE
        import custom_warehouseScripts.custom_warehouseServerSystem.ContData as Data
        import custom_warehouseScripts.custom_warehouseServerSystem.CustomCmd as Cmd
        import custom_warehouseScripts.custom_warehouseServerSystem.GlobalConfig as GCfg
        # 全局动态配置须先于 ContData / AnyEvent 初始化
        self.GlobalConfig = GCfg.GlobalConfig(self)
        """:type: custom_warehouseScripts.custom_warehouseServerSystem.GlobalConfig.GlobalConfig"""
        self.ContData = Data.ContData(self)
        """:type: custom_warehouseScripts.custom_warehouseServerSystem.ContData.ContData"""
        self.AnyEvent = AE.AnyEvent(self)
        """:type: custom_warehouseScripts.custom_warehouseServerSystem.AnyEvent.AnyEvent"""
        self.CustomCmd = Cmd.CustomCmd(self)
        """:type: custom_warehouseScripts.custom_warehouseServerSystem.CustomCmd.CustomCmd"""

        # playerId -> {'name': str} 玩家名缓存（playerid 跨会话稳定）
        self.player_info_map = {}
        # 服务端发起到客户端请求时，暂存等待客户端回调的函数
        self.BackFun = {}

        self.GetMod()
        self.ListenEvents()

    # =========================== 事件注册 ===========================

    def ListenEvents(self):
        """集中注册引擎事件和自定义事件"""
        ENS = serverApi.GetEngineNamespace()
        ESN = serverApi.GetEngineSystemName()
        self.ListenForEvent(ENS, ESN, "CustomCommandTriggerServerEvent", self.CustomCmd, self.CustomCmd.CustomCmdEvent)
        self.ListenForEvent(CG.Mod_Name, CG.C_Name, "AnyEvent", self.AnyEvent, self.AnyEvent.AnyEvent)
        self.ListenForEvent(ENS, ESN, "ClientLoadAddonsFinishServerEvent", self, self.OnPlayerJoin)
        self.ListenForEvent(ENS, ESN, "PlayerIntendLeaveServerEvent", self, self.OnPlayerLeave)

    # =========================== 统一联动模组设置 ===========================

    def GetMod(self, isreget=False):
        """统一联动模组设置：服务端通过 GetSystem 获取其他 mod 的系统实例。
        按需复制此行添加更多联动：self.XxxClass = serverApi.GetSystem('mod_id', 'mod_idServerSystem')
        """
        self.XxxxModClass = serverApi.GetSystem('xxxx', 'xxxxServerSystem')
        """:type: object | None"""
        # 5s 后重试一次，避免目标 mod 尚未加载完成
        if not isreget:
            CF.CreateGame(LevelID).AddTimer(5.0, self.GetMod, True)

    # =========================== 玩家生命周期 ===========================

    def OnPlayerJoin(self, args):
        """玩家进服初始化：缓存玩家名"""
        playerid = args.get('playerId')
        if not playerid:
            return
        try:
            name = CF.CreateName(playerid).GetName() or ''
        except Exception:
            name = ''
        self.player_info_map[playerid] = {'name': name}

    def OnPlayerLeave(self, args):
        """玩家即将离开：清缓存并强制保存"""
        playerid = args.get('playerId')
        self.player_info_map.pop(playerid, None)
        try:
            self.ContData.FlushSave()
        except Exception as e:
            print '[ModName] FlushSave 失败:', e

    # =========================== 通信：TC/BackFun ===========================

    def Time05Event(self):
        """轮询检查服务端发起请求的回调，超时（>10s）则兜底清理"""
        for _d in list(self.BackFun):
            if self.BackFun.get(_d, None):
                if time.time() - self.BackFun[_d]['time'] > 10:
                    try:
                        self.BackFun[_d]['back']({'data': {}, 'state': False})
                        del self.BackFun[_d]
                    except:
                        del self.BackFun[_d]

    def OnClientBack(self, args):
        """客户端对服务端发起请求的回调入口"""
        back = args['back']
        data = args['backdata']
        if self.BackFun.get(back, None):
            if type(self.BackFun[back]['back']) is tuple:
                for _ in self.BackFun[back]['back']:
                    _(data)
                del self.BackFun[back]
            else:
                self.BackFun[back]['back'](data)
                del self.BackFun[back]
        else:
            print '客户端无法找到服务端回调', back

    def TC(self, playerid, data, back=None, eventsuid=''):
        """服务端向指定客户端发起请求并接收回调（对应客户端 TS）
        :param playerid: 目标玩家 id
        :param data: 发送数据 {'lx': 'xxx', ...}
        :param back: 回调函数，客户端处理完成后触发
        :param eventsuid: 唯一标识，用于去重
        """
        if eventsuid:
            uids = eventsuid
        else:
            uids = uuid.uuid4().hex[:6]
        if self.BackFun.get(eventsuid, None) is None:
            if back:
                self.BackFun[uids] = {'back': back, 'time': time.time()}
            self.NotifyToClient(playerid, 'AnyEvent', {'data': data, 'back': uids if back else None})
            return True
        else:
            return False, '正在处理中...请稍后'

    # =========================== 对外 API 接口 ===========================

    def API_GetGlobalConfig(self, key=None):
        """读取全局配置。key=None 返回全量 dict；指定 key 返回单项值"""
        if key is None:
            return self.GlobalConfig.GetAll()
        return self.GlobalConfig.Get(key)

    def API_SetGlobalConfig(self, key, value):
        """设置全局配置
        :return: (ok: bool, msg: str)
        """
        return self.GlobalConfig.Set(key, value)

    def API_ResetGlobalConfig(self, key):
        """重置某项配置为默认值
        :return: (ok: bool, msg: str)
        """
        return self.GlobalConfig.Reset(key)
