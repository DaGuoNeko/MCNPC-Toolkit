
# -*- coding: utf-8 -*-
Mod_Name = "custom_warehouse"
C_Name = "custom_warehouseClientSystem"
C_Path = "custom_warehouseScripts.custom_warehouseClientSystem.custom_warehouseClientSystem.custom_warehouseClientSystem"

S_Name = "custom_warehouseServerSystem"
S_Path = "custom_warehouseScripts.custom_warehouseServerSystem.custom_warehouseServerSystem.custom_warehouseServerSystem"

Ui_CommonName = "custom_warehouse_common"

# -------------------------------------- ExtraData 键名配置 --------------------------------------
# ExtraData 主键（schema 版本号，便于将来迁移）
KV_KEY_MAIN = 'ModName_data_v1'

# 全局动态配置 ExtraData 主键（与主数据独立；供 OP 在线修改）
KV_KEY_GLOBAL_CONFIG = 'ModName_global_cfg_v1'

# -------------------------------------- 节流保存配置 --------------------------------------
# 写操作后延迟 SAVE_THROTTLE_SECONDS 落盘；调度器以 SAVE_TIMER_INTERVAL 检查
SAVE_THROTTLE_SECONDS = 5.0
SAVE_TIMER_INTERVAL = 1.0
