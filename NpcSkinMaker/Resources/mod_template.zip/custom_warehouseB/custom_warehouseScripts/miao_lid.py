# coding=utf-8
# 版本 1.18
# 大果喵专属复用轮子以及算法。
import time
import math
import re
import random
import datetime
import json
import hashlib
from types import MethodType


# -------------------------------------- 本模组专用 --------------------------------------

def mc_time_str(tick):
    """获取mc时间"""
    tick = tick % 24000
    hour = ((tick / 1000) + 6) % 24
    minute = int((tick % 1000) * 60 / 1000)
    return "%02d:%02d" % (hour, minute)


def format_game_number(num):
    try:
        num = float(num)
    except (TypeError, ValueError):
        return "0"

    abs_num = abs(num)

    if abs_num < 1000:
        if num == int(num):
            return str(int(num))
        return "%.1f" % num

    if abs_num < 1000000:
        value = num / 1000.0
        suffix = 'K'
    elif abs_num < 1000000000:
        value = num / 1000000.0
        suffix = 'M'
    else:
        value = num / 1000000000.0
        suffix = 'B'

    value = round(value, 1)

    if value == int(value):
        return "%d%s" % (int(value), suffix)
    else:
        return "%.1f%s" % (value, suffix)


def GetAaBbPos(a_xyz, b_xyz):
    """将2个坐标转换为 AABB 形式,保证a点坐标都是小于b点坐标
    规范化两个点的 xyz 范围
    :param a_xyz: (x, y, z) 字符串坐标
    :param b_xyz: (x, y, z) 字符串坐标
    :return: ((ax, ay, az), (bx, by, bz)) 均为字符串，异常返回 None
    """
    try:
        if len(a_xyz) != 3 or len(b_xyz) != 3:
            return None

        # 转成 float（兼容整数 / 小数 / 负数）
        ax, ay, az = map(float, a_xyz)
        bx, by, bz = map(float, b_xyz)

        # 每个轴单独比较并交换
        if ax > bx:
            ax, bx = bx, ax
        if ay > by:
            ay, by = by, ay
        if az > bz:
            az, bz = bz, az

        # 再转回字符串
        return (ax, ay, az), (bx, by, bz)
    except Exception:
        return None


def make_nbt_hash(userData, isuserdata=False):
    """
    item = 背包里的单个 item dict
    isuserdata = 是否传进来的是 userData字典,否则整个物品数据
    """

    def normalize(obj):
        if isinstance(obj, dict):
            return {k: normalize(obj[k]) for k in sorted(obj)}
        elif isinstance(obj, list):
            return [normalize(x) for x in obj]
        else:
            return obj

    def stable_dump(obj):
        return repr(obj)

    if not isuserdata:
        userData = userData.get('userData')
        if not userData:
            return None

    normalized = normalize(userData)
    dumped = stable_dump(normalized)

    return hashlib.new('md5', dumped).hexdigest()


def GtePistonMoveBlockPos(pos, action, facing):
    """获取被活塞推动后的方块坐标列表"""
    poss = pos

    def facings(cot):
        if cot == 'add':
            if facing == 4:
                poss[0] += 1
            elif facing == 2:
                poss[2] += 1
            elif facing == 5:
                poss[0] -= 1
            elif facing == 3:
                poss[2] -= 1
            elif facing == 1:
                poss[1] += 1
            elif facing == 0:
                poss[1] -= 1
        elif cot == 'red':
            if facing == 5:
                poss[0] -= 1
            elif facing == 3:
                poss[2] -= 1
            elif facing == 4:
                poss[0] += 1
            elif facing == 2:
                poss[2] += 1
            elif facing == 0:
                poss[1] -= 1
            elif facing == 1:
                poss[1] += 1

    if action == 'expanding':
        facings('add')
    else:
        facings('red')
    return poss


# ------------------------------------------------------------------------- 网易 Minecraft ----------------------------------------------------------------------------------------
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi

CF = serverApi.GetEngineCompFactory()
CCF = clientApi.GetEngineCompFactory()
leveld = serverApi.GetLevelId()


def GetBlockSpawnEntity(pos=(0, 0, 0), y=2, dia=0, defapos=(0, -100, 0)):
    """获取某坐标是否能生成实体，参数: 坐标，y高度， 维度, 默认出生坐标 返回: 空时返回None，否则返回能生成的坐标"""
    trueblocklist = []
    trueblockposlist = []
    for trblock in [(pos[0], pos[1] + ints, pos[2]) for ints in xrange(y)]:
        compinfo = CF.CreateBlockInfo(leveld)
        blockinfo = compinfo.GetBlockNew(trblock, dia)
        if blockinfo and not compinfo.GetBlockBasicInfo(blockinfo['name']).get('solid', True):
            trueblocklist.append(True)
            trueblockposlist.append(trblock)
        else:
            trueblocklist.append(False)
            trueblockposlist.append(trblock)
    truepos = find_consecutive_duplicates(trueblocklist, 2, True)
    if truepos:
        return trueblockposlist[min(truepos)]
    return


def GetEditStateInt(args={}, noneint='0'):
    """文本框变化—整数"""
    a = args['Text']
    try:
        try:
            if a == '':  # 空的就设置为空
                a = ''
            else:
                int(a)  # 判断是否是数字这里是核心部分
                a = a
        except:
            pass
        if args.get('Mode', '') == 'Finished':  # 解决空问题
            if a == '':
                a = noneint
    except:
        return
    return a


def GetEditContInt(Ints='0', MaxInt='10000000000', MinInt='0'):
    """文本框内容—整数"""
    b = Ints
    try:
        if int(float(b)) > int(float(MaxInt)):  # 限制最大数
            b = MaxInt
        elif int(float(b)) < int(float(MinInt)):  # 限制最小数
            b = MinInt
    except:
        return
    return str(int(float(b)))


def GetEditStateFloat(args={}, noneint='0.1'):
    """文本框变化—浮点数"""
    a = args['Text']
    try:
        try:
            if a == '':  # 空的就设置为空
                a = ''
            else:
                int(a)  # 判断是否是数字这里是核心部分
                a = a
        except:
            pass
        if args['Mode'] == 'Finished':  # 解决空问题
            if a == '':
                a = noneint
    except:
        return
    return a


def GetEditContFloat(Ints='0', MaxInt='10000000000.0', MinInt='0.0'):
    """文本框内容—浮点数"""
    b = Ints
    try:
        if float(b) > float(MaxInt):  # 限制最大数
            b = MaxInt
        elif float(b) < float(MinInt):  # 限制最小数
            b = MinInt
    except:
        return
    return b


def CreateItems(newItemName, newAuxValue=0, count=None, userData={}):
    """构造物品数据"""
    itemdata = {
        'newItemName': newItemName,
        'newAuxValue': newAuxValue
    }
    if isinstance(count, int):
        itemdata['count'] = count
    if userData:
        itemdata['userData'] = userData
    return itemdata


def NewItem(itemdata):
    """获取优化后的物品"""
    if itemdata:
        newitemdata = {
            'count': itemdata.get('count', 0),
            'newItemName': itemdata.get('newItemName', 'air'),
            'newAuxValue': itemdata.get('newAuxValue', 0),
            'showInHand': itemdata.get('showInHand', True),
            'userData': itemdata.get('userData', {})
        }
        return newitemdata
    else:
        return itemdata


def GetItemisName(itemdata):
    """获取物品名字"""
    name = ''
    if itemdata and itemdata.get("userData", None) and itemdata['userData'].get('display', None) and itemdata['userData']['display'].get('Name', None):
        name = itemdata['userData']['display']['Name']['__value__']
    return name


def GetItemsDurability(itemDict, system=False):
    """获取物品耐久,False为服务端获取，True为客户端获取"""
    if system:
        itemComp = CF.CreateItem(serverApi.GetLevelId())
        basicInfo = itemComp.GetItemBasicInfo(itemDict.get('newItemName', ''), itemDict.get('newAuxValue', 0))
    else:
        itemComp = CCF.CreateItem(clientApi.GetLevelId())
        basicInfo = itemComp.GetItemBasicInfo(itemDict.get('newItemName', ''), itemDict.get('newAuxValue', 0))
    if basicInfo:
        maxDurability = basicInfo.get('maxDurability', 0)
        maxDurability = itemDict.get('ModMaxDamage', maxDurability)
        durability = itemDict.get('durability', maxDurability)
        try:
            if itemDict.get('userData', None):
                if itemDict['userData'].get('ModMaxDamage', None):
                    if itemDict['userData'].get('ModMaxDamage', {}).get('__value__', None):
                        maxDurability = itemDict['userData'].get('ModMaxDamage', {}).get('__value__', maxDurability)
                    else:
                        maxDurability = itemDict['userData'].get('ModMaxDamage', maxDurability)
                if itemDict['userData'].get('Damage', None):
                    if str(itemDict['userData'].get('Damage', {}).get('__value__', '')):
                        durability = maxDurability - itemDict['userData'].get('Damage', {}).get('__value__', durability)
                    else:
                        durability = maxDurability - itemDict['userData'].get('Damage', durability)
        except:
            return 0, 0
        return durability, maxDurability
    return 0, 0


def GetItemisEnchant(item):
    """获取物品是否附魔"""
    isEnchant = False
    # print item
    try:
        if item.get("enchantData"):
            isEnchant = True
        if item.get("userData"):
            if item.get("userData").get('ench'):
                isEnchant = True
        return isEnchant
    except:
        return isEnchant


def fairDictExc(exckey, dict1, dict2):
    """ 去某键，然后比较俩个字典是否一样"""
    try:
        dict1.pop(exckey, None)
        dict2.pop(exckey, None)
        if dict1 == dict2:
            return True
        else:
            return False
    except:
        return False


def fairdicitems(dict1, dict2):
    """判断是否为同一item，只有itemName和auxValue均相同才返回True"""
    if not dict1 or not dict2:
        return False
    if dict1.get("newItemName", "item1") != dict2.get("newItemName", "item2"):
        return False
    if dict1.get("newAuxValue") != dict2.get("newAuxValue"):
        return False
    if dict1.get("userData") != dict2.get("userData"):
        return False
    if dict1.get("durability") != dict2.get("durability"):
        return False
    return True


def getitemCnStr(items, system=False):
    """获取物品的中文名字, true为在客户端获取，反之服务端"""
    if system:
        BasicInfo = CCF.CreateItem(clientApi.GetLevelId()).GetItemBasicInfo(items.get('newItemName', ''), items.get('newAuxValue', 'air'))
        if BasicInfo:
            itemStr = BasicInfo['itemName']
        else:
            itemStr = '未知'
    else:
        BasicInfo = CF.CreateItem(serverApi.GetLevelId()).GetItemBasicInfo(items.get('newItemName', ''), items.get('newAuxValue', 0))
        if BasicInfo:
            itemStr = BasicInfo['itemName']
        else:
            itemStr = '未知'
    names = GetItemisName(items)
    if GetItemisName(items) == '':
        return itemStr
    else:
        return names


def GetEntityName(entityid, system=False, Identifier=False):
    """获取实体的中文名字,identifier为True时使用指定的本地化id进行获取, true为在客户端获取，反之服务端"""
    Name = '未知'
    if system:
        compname = CCF.CreateName(entityid)
        compgame = CCF.CreateGame(clientApi.GetLevelId())
        compstr = CCF.CreateEngineType(entityid)
    else:
        compname = CF.CreateName(entityid)
        compgame = CF.CreateGame(serverApi.GetLevelId())
        compstr = CF.CreateEngineType(entityid)

    # 直接本地化id获取中文名
    if Identifier:
        _d = compgame.GetChinese("entity.{}.name".format(entityid.split(':')[1]))
        Name = Name if _d.count('entity.') else _d
        return Name

    _str = compstr.GetEngineTypeStr()
    _name = compname.GetName()
    try:
        if _name:
            Name = _name
        else:
            _d = compgame.GetChinese("entity.{}.name".format(_str.split(':')[1]))
            Name = Name if _d.count('entity.') else _d
    except:
        pass
    return Name


def GetItemEnchantInfo(itemsdata, encid):
    """获取物品指定附魔信息"""
    try:
        if itemsdata and itemsdata.get('userData', None) and itemsdata['userData'].get('ench', None):
            for ench in itemsdata['userData']['ench']:
                if ench.get('id', None).get('__value__', None) == 255 and ench.get('modEnchant', None).get('__value__', None) == encid:
                    return ench['lvl']['__value__'], encid
                elif ench.get('id', None).get('__value__', None) == encid:
                    return ench['lvl']['__value__'], encid
        return None
    except:
        return None


def GetItemColor(itemdata):
    """获取物品的颜色id"""
    try:
        if itemdata and itemdata.get('userData', None) and 'customColor' in itemdata['userData']:
            return itemdata['userData']['customColor']['__value__']
        return -1
    except:
        return -1


def GetItemsTrim(itemdata):
    """获取物品的trim值, -> [模板，材料]"""
    try:
        if itemdata and itemdata.get('userData', None) and 'Trim' in itemdata['userData']:
            return itemdata['userData']['Trim']['Pattern']['__value__'], itemdata['userData']['Trim']['Material']['__value__']
        return ['', '']
    except:
        return ['', '']


def GetItemsIsLock(itemdata):
    """获取物品是否是红标物品"""
    try:
        if itemdata and itemdata.get('userData', None) and 'minecraft:item_lock' in itemdata['userData']:
            return True if itemdata['userData']['minecraft:item_lock']['__value__'] else False
        return False
    except:
        return False


# ------------------------------------------------------------------------- 其他 ----------------------------------------------------------------------------------------

def sort_list(lst, reverse=False):
    """
    对列表进行字母或数字的排序，支持中文和数字排序，并可以选择升序或降序。

    参数:
        lst (list): 待排序的列表
        reverse (bool): 如果为True，列表将按降序排序；默认False（升序）

    返回:
        list: 排序后的列表
    """
    return sorted(lst, key=lambda x: str(x), reverse=reverse)


def is_integer(s):
    # type: (str) -> bool
    """检查是否是数字，并且是否是整数"""
    try:
        int(s)
        return True
    except:
        return False


def is_float(s):
    # type: (str) -> bool
    """检查是否是数字，并且是否是浮点数"""
    try:
        float(s)
        return True
    except:
        return False


def minecraft_is_value_in_range(range_str, value):
    # type: (str, float) -> bool
    """模拟 Minecraft 指令中的范围查询，例如: '..15', '1..5', '10..', '42', '!..15', '!1..5', '!42'"""
    try:
        is_negated = range_str.startswith('!')
        if is_negated:
            range_str = range_str[1:]
        
        if '..' not in range_str:
            result = float(range_str) == value
        else:
            start_str, end_str = range_str.split('..', 1)
            start = float(start_str) if start_str else None
            end = float(end_str) if end_str else None
            
            if start is not None and end is not None:
                result = start <= value <= end
            elif start is None:
                result = value <= end
            else:
                result = value >= start
        
        return (not result) if is_negated else result
    except (ValueError, AttributeError):
        return False


def minecraft_is_string_equal(str_expr, value):
    """
    判断字符串是否相等，支持反向比较（使用 '!' 前缀）。
    如果有 '!'，则判断字符串是否不相等。

    参数:
        str_expr (str): 比较字符串表达式，可能带有 '!'（如 '!hello' 表示不等于 'hello'）。
        value (str): 要与之比较的字符串。

    返回:
        bool: 如果字符串相等（或不等，取决于是否有 '!' 前缀），返回 True，否则返回 False。
    """
    try:
        # 检查是否有 "!" 前缀（反向查询）
        is_negated = str_expr.startswith("!")
        if is_negated:
            str_expr = str_expr[1:]  # 去掉 "!"，进行普通的字符串比较

        # 比较字符串是否相等
        result = str_expr == value

        # 如果有 "!"，取反结果
        return not result if is_negated else result
    except Exception:
        # 如果发生异常（例如类型错误等），返回 False
        return False


def GetDataDefDefault(data, defaultvalue=None):
    """获取数据，数据为空的时候返回给予的默认值"""
    if data:
        return data
    else:
        return defaultvalue


def CreateDynamicBind(ui, function, tag=""):
    # type: (any, any, str) -> None
    '''
    给UI系统动态创建绑定\n
    注意, CreateUI创建的界面, 在Create函数中, 调用此接口绑定无效\n
    PushScreen的界面, Create中调用有效\n
    ui: UI系统实例
    function: 给UI创建此方法
    tag: 在方法名尾部追加此标签
    '''
    function.__name__ = function.__name__ + "_" + tag
    setattr(ui, function.__name__, MethodType(function, ui))


def get_to_zero(num, tolerance=1e-15):
    """判断一个数是否无限接近0，是则返回0.0， 否则返回原数"""
    if abs(num) < tolerance:
        return 0.0
    else:
        return num


def sort_dict_by_key(d, k):
    """按照字典的某个键的值进行排序，返回一个列表"""
    items = list(d.items())
    print items
    items.sort(key=lambda item: item[1][k])
    return items


def check_coordinate_in_rectangle(coord, point_a, point_b):
    """检测某坐标是否在ab点坐标范围内,参数: 待检测的坐标，a点坐标，b点坐标  返回: bool"""
    return all(min(point_a[i], point_b[i]) <= coord[i] <= max(point_a[i], point_b[i]) for i in range(3))


def find_consecutive_duplicates(lst, num, target):
    """根据参数搜索列表相同相邻的的元素索引位置,参数: 列表，几个相同，找什么元素  返回: 列表"""
    result = []
    length = len(lst)
    for i in range(length - num + 1):
        if lst[i:i + num] == [target] * num:
            result.append(i)
    return result


def sort_items_by_keyword(items, keyword, key=''):
    """搜索某列表中指定键的值，返回列表"""
    result = []
    for item in items:
        if key in item and keyword in item[key]:
            result.append(item)
    return result


def timestamp_to_time(timestamp):
    """吧时间戳转换成时间的格式"""
    # 将时间戳转换为datetime对象
    dt_object = datetime.datetime.fromtimestamp(timestamp)
    # 使用strftime函数格式化时间
    formatted_time = dt_object.strftime('%Y-%m-%d %H:%M:%S')
    return formatted_time


def get_timestamp_to_time(_TS=0):
    """根据时间戳获取剩余的时间格式,返回 天， 小时， 分钟"""
    days = _TS // (24 * 3600)
    timestamp = _TS % (24 * 3600)
    hours = timestamp // 3600
    timestamp %= 3600
    minutes = timestamp // 60
    return days, hours, minutes


# 定义一个函数，根据给定的x,y,z坐标，返回一个坐标列表，表示伤害数值的跳动动画
def damage_jump(x, y, z):
    # 定义一个空列表，用来存储坐标
    coords = []
    # 定义一个变量，表示跳动的高度
    height = 0.8
    # 定义一个变量，表示跳动的深度
    depth = 1
    # 定义一个变量，表示跳动的步数
    steps = 30
    # 定义一个变量，表示每一步的垂直位移
    dy = height / steps
    # 定义一个变量，表示每一步的水平位移
    dz = depth / steps
    # 定义一个变量，表示重力加速度
    g = -2 * dy / (steps ** 2)
    # 随机生成一个方向，1表示向前，-1表示向后
    direction = random.choice([1, -1])
    # 使用一个循环，计算每一步的坐标，并添加到列表中
    for i in range(steps):
        # 计算当前步数的x坐标，假设不变
        x_curr = x + direction * i * dz
        # 计算当前步数的y坐标，假设向上为正方向
        y_curr = y + i * dy + g * (i ** 2) / 2
        # 计算当前步数的z坐标，根据方向乘以dz
        z_curr = z
        # 将当前步数的坐标添加到列表中
        coords.append((x_curr, y_curr, z_curr))
    # 返回坐标列表
    return coords


def get_string_type(input_string):
    """获取字符串是数字还是字符串类型"""
    if input_string.isdigit():
        return int
    else:
        return str


def _HSB2RGB(h, s, v):
    """# hsb 转 rgb"""
    if s == 0:
        return v, v, v
    if h >= 360:
        h = 0
    i = int((h / 60.0) % 6)
    f = (h / 60.0) - i
    p = v * (1.0 - s)
    q = v * (1.0 - s * f)
    t = v * (1.0 - s * (1.0 - f))
    if i == 0:
        if t > 1:
            t = 0.0
        return v, t, p
    if i == 1:
        return q, v, p
    if i == 2:
        return p, v, t
    if i == 3:
        return p, q, v
    if i == 4:
        return t, p, v
    if i == 5:
        return v, p, q


def RGB2HSB(r, g, b):
    """# rgb 转 hsb"""
    r, g, b = r * 255, g * 255, b * 255
    maxs = max(r, g, b)
    mins = min(r, g, b)
    A = maxs - mins
    hsb_B = maxs / 255.0
    hsb_S = 0 if maxs == 0 else A / maxs
    hsb_H = 0
    if A == 0:
        hsb_H = 0
    elif maxs == r and g >= b:
        hsb_H = (g - b) * 60.0 / A + 0
    elif maxs == r and g < b:
        hsb_H = (g - b) * 60.0 / A + 360
    elif maxs == g:
        hsb_H = (b - r) * 60.0 / A + 120
    elif maxs == b:
        hsb_H = (r - g) * 60.0 / A + 240
    return hsb_H, hsb_S, hsb_B


def move_list_index(lst, index, strea):
    """对元素进行下移或上移"""
    if strea:
        if index > 0:
            lst[index], lst[index - 1] = lst[index - 1], lst[index]
    else:
        if index < len(lst) - 1:
            lst[index], lst[index + 1] = lst[index + 1], lst[index]


def get_element(lst, index, default_value):
    """列表索引不到元素时返回一个默认值"""
    try:
        return lst[index]
    except:
        return default_value


def extract_brackets_content(s, exvalue='{}'):
    """ 使用正则表达式匹配大括号内的内容"""
    if exvalue == '{}':
        result = re.findall(r'\{(.*?)\}', s)
    else:
        result = re.findall(r'\((.*?)\)', s)
    return result


def GetABposDac(pos1, pos2):
    """获取A点与B点的距离,需传入A点坐标，和B点坐标"""
    x1 = pos1[0]
    y1 = pos1[1]
    z1 = pos1[2]

    x2 = pos2[0]
    y2 = pos2[1]
    z2 = pos2[2]
    d = math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2 + (z1 - z2) ** 2)
    return d


def GetABPosHub(pos1, pos2):
    """获取A点与B点的中心点坐标,需传入A点坐标，和B点坐标"""
    x1 = pos1[0]
    y1 = pos1[1]
    z1 = pos1[2]
    x2 = pos2[0]
    y2 = pos2[1]
    z2 = pos2[2]
    o1 = (x1 + x2) / 2
    o2 = (y1 + y2) / 2
    o3 = (z1 + z2) / 2
    s = (o1, o2, o3)
    return s


def get_coordinates_within_circle(center, diameter):
    """以A点为中心获取直径圆形内的所有坐标，需传入A点坐标，和直径, 返回列表"""
    coordinates = []
    radius = diameter / 2
    min_x = int(center[0] - radius)
    max_x = int(center[0] + radius)
    min_z = int(center[2] - radius)
    max_z = int(center[2] + radius)

    for x in range(min_x, max_x + 1):
        for y in range(center[1] - int(radius), center[1] + int(radius) + 1):
            for z in range(min_z, max_z + 1):
                if math.sqrt((x - center[0]) ** 2 + (z - center[2]) ** 2) <= radius:
                    coordinates.append((x, y, z))

    return coordinates


def radaoms(ints):
    """概率成功，需传入概率数值"""
    b = random.randint(1, 100)
    if ints >= b:
        return True
    else:
        return False


def floatradaom(floatint):
    """概率成功，需传入概率数值,支持小数点"""
    floats = round(floatint, 1)
    if floats < 1.0:
        if radaoms(1):
            if floats >= random.random():
                return True
        return False
    else:
        return radaoms(int(floats))


def GetBlockPosNew(one, two):
    """
    获取从起点到终点之间的所有方块坐标（包含起点和终点）
    参数:
        start (tuple): 起点坐标 (x1, y1, z1)
        end (tuple): 终点坐标 (x2, y2, z2)

    返回:
        list: 包含所有坐标的列表，每个坐标表示为 (x, y, z) 元组
    """
    x1, y1, z1 = one
    x2, y2, z2 = two

    # 确保x1 <= x2，y1 <= y2，z1 <= z2，方便生成范围
    if x1 > x2:
        x1, x2 = x2, x1
    if y1 > y2:
        y1, y2 = y2, y1
    if z1 > z2:
        z1, z2 = z2, z1

    # 生成坐标范围（包含终点）
    x_range = range(x1, x2 + 1)
    y_range = range(y1, y2 + 1)
    z_range = range(z1, z2 + 1)

    # 使用列表推导式生成所有坐标组合
    coordinates = [(x, y, z) for x in x_range for y in y_range for z in z_range]

    return coordinates


def OnGteGetFootPos(pos):
    """正确的获取脚底坐标"""
    return tuple(map(lambda x: int(math.floor(x)), pos))


def unicode_convert(input):
    """'去掉带u的字典,需传入带u的字典"""
    if isinstance(input, dict):
        return {unicode_convert(key): unicode_convert(value) for key, value in input.iteritems()}
    elif isinstance(input, list):
        return [unicode_convert(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input


def get_relative_coordinates(startpos, apos, bpos):
    """根据起点坐标获取ab点坐标之间所有方块的相对坐标列表，参数 起点坐标，a点坐标，b点坐标"""
    relative_coordinates = []
    for x in range(apos[0], bpos[0] + 1):
        for y in range(apos[1], bpos[1] + 1):
            for z in range(apos[2], bpos[2] + 1):
                relative_coordinates.append((x - startpos[0], y - startpos[1], z - startpos[2]))
    return relative_coordinates


def generate_hash_dict(data):
    """将 datalist 中的值转换为哈希字典"""
    hash_dict = {}
    for key, value in data.items():
        hash_dict[key] = hash(json.dumps(value, sort_keys=True))
    return hash_dict


def PRD_C(Chance):
    _C = {
        '0.01': [0.000156, 6411], '0.02': [0.00062, 1613], '0.03': [0.001386, 722], '0.04': [0.002449, 409], '0.05': [0.003802, 264], '0.06': [0.00544, 184], '0.07': [0.007359, 136], '0.08': [0.009552, 105], '0.09': [0.012016, 84],
        '0.1': [0.014746, 68], '0.11': [0.017736, 57], '0.12': [0.020983, 48], '0.13': [0.024482, 41], '0.14': [0.02823, 36], '0.15': [0.032221, 32], '0.16': [0.036452, 28], '0.17': [0.04092, 25], '0.18': [0.04562, 22],
        '0.19': [0.050549, 20], '0.2': [0.055704, 18], '0.21': [0.061081, 17], '0.22': [0.066676, 15], '0.23': [0.072488, 14], '0.24': [0.078511, 13], '0.25': [0.084744, 12], '0.26': [0.091183, 11], '0.27': [0.097826, 11],
        '0.28': [0.10467, 10], '0.29': [0.111712, 9], '0.3': [0.118949, 9], '0.31': [0.126379, 8], '0.32': [0.134001, 8], '0.33': [0.141805, 8], '0.34': [0.14981, 7], '0.35': [0.157983, 7], '0.36': [0.166329, 7], '0.37': [0.174909, 6], '0.38': [0.183625, 6], '0.39': [0.192486, 6],
        '0.4': [0.201547, 5], '0.41': [0.21092, 5], '0.42': [0.220365, 5], '0.43': [0.229899, 5], '0.44': [0.23954, 5], '0.45': [0.249307, 5], '0.46': [0.259872, 4], '0.47': [0.270453, 4], '0.48': [0.281008, 4],
        '0.49': [0.291552, 4], '0.5': [0.302103, 4], '0.51': [0.312677, 4], '0.52': [0.323291, 4], '0.53': [0.33412, 3], '0.54': [0.34737, 3], '0.55': [0.360398, 3], '0.56': [0.3732173, 3], '0.57': [0.38584, 3], '0.58': [0.398278, 3], '0.59': [0.410545, 3], '0.6': [0.42265, 3],
        '0.61': [0.434604, 3], '0.62': [0.446419, 3], '0.63': [0.458104, 3], '0.64': [0.46967, 3], '0.65': [0.481125, 3], '0.66': [0.492481, 3], '0.67': [0.507463, 2], '0.68': [0.529412, 2], '0.69': [0.550725, 2],
        '0.7': [0.571429, 2], '0.71': [0.591549, 2], '0.72': [0.611111, 2], '0.73': [0.630137, 2], '0.74': [0.648649, 2], '0.75': [0.666667, 2], '0.76': [0.684211, 2], '0.77': [0.701299, 2], '0.78': [0.717949, 2],
        '0.79': [0.734177, 2], '0.8': [0.75, 2], '0.81': [0.765432, 2], '0.82': [0.780488, 2], '0.83': [0.795181, 2], '0.84': [0.809524, 2], '0.85': [0.823529, 2], '0.86': [0.837209, 2], '0.87': [0.850575, 2],
        '0.88': [0.863636, 2], '0.89': [0.876404, 2], '0.9': [0.888889, 2], '0.91': [0.901099, 2], '0.92': [0.913043, 2], '0.93': [0.924731, 2], '0.94': [0.93617, 2], '0.95': [0.947368, 2], '0.96': [0.958333, 2], '0.97': [0.969072, 2],
        '0.98': [0.979592, 2], '0.99': [0.989899, 2], '1.0': [1.0, 1]
    }
    return _C[str(round(Chance / 100, 2))]


def deep_get(data, path, delimiter="."):
    """
    通过路径字符串深度查询嵌套字典和列表中的值。

    参数:
        data (dict | list): 需要查询的嵌套字典或列表
        path (str): 路径字符串，例如 "key1.key2[0].key3"
        delimiter (str): 路径分隔符，默认是 '.'

    返回:
        any: 查询到的值，如果路径无效返回 None
    """
    current = data
    # 分解路径，支持 "." 和 "[index]" 的格式
    parts = re.split(r"{0}|\[(\d+)\]".format(re.escape(delimiter)), path)
    parts = [p for p in parts if p]  # 去掉空字符串

    for part in parts:
        try:
            if part.isdigit():  # 如果是索引，转换为整数
                current = current[int(part)]
            else:  # 否则认为是字典键
                current = current[part]
        except (KeyError, IndexError, TypeError):
            return None  # 如果路径无效，返回 None

    return current


def new_check_string(s, f={'/', '.', '(', ')'}):
    # type: (str, set) -> bool
    """新的检查字符串是否合法，s=要检查的字符串, f=要检查的字符集"""
    if set(s) & f:
        return False
    return True


def GetBiomeCnName(biome_id, system=False):
    """获取群系的中文名字, system=True为在客户端获取，反之服务端"""
    if system:
        compGame = CCF.CreateGame(clientApi.GetLevelId())
    else:
        compGame = CF.CreateGame(serverApi.GetLevelId())

    # 获取中文译名
    biome_chinese = compGame.GetChinese('biome.' + biome_id + '.name')

    # 如果没有找到翻译，返回原ID
    if biome_chinese.startswith('biome.'):
        return str(biome_id)

    # 转换为 str 避免编码问题
    return str(biome_chinese)


# -------------------------------------- 屏幕外目标追踪箭头算法 --------------------------------------

def _normalize_angle(angle):
    # type: (float) -> float
    """将角度标准化到 [-180, 180] 区间。"""
    angle = angle % 360.0
    if angle > 180.0:
        angle -= 360.0
    return angle


def get_task_icon_screen_pos(
        player_pos,
        camera_yaw,
        camera_pitch,
        target_pos,
        screen_size,
        edge_left=20.0,
        edge_right=20.0,
        edge_top=10.0,
        edge_bottom=80.0,
        center_angle=10.0
):
    # type: (tuple, float, float, tuple, tuple, float, float, float, float, float) -> tuple
    """计算屏幕外目标追踪箭头的屏幕坐标与旋转角。

    核心算法：将世界坐标中的目标位置映射到屏幕上的像素坐标，
    当目标不在视野内时，箭头贴在屏幕边缘指向目标方位。

    参数：
        player_pos: 玩家世界坐标 (x, y, z)
        camera_yaw: 摄像机水平旋转角（度）
        camera_pitch: 摄像机俯仰角（度）
        target_pos: 目标世界坐标 (x, y, z)
        screen_size: 屏幕尺寸 (width, height)
        edge_left/right/top/bottom: 屏幕边缘留白（像素）
        center_angle: 中心判定区域半角（度），目标在此区域内视为"在准心附近"

    返回：(screen_x, screen_y, rotate_angle, in_center)
        screen_x, screen_y: 箭头在屏幕上的左上角像素坐标
        rotate_angle: 箭头旋转角（度，0=向上）
        in_center: 目标是否在准心中心判定区内
    """
    atan2 = math.atan2
    sqrt = math.sqrt
    degrees = math.degrees
    radians = math.radians
    cos = math.cos

    # 1. 计算世界坐标相对向量
    dx = target_pos[0] - player_pos[0]
    dy = target_pos[1] - player_pos[1]
    dz = target_pos[2] - player_pos[2]

    # 特殊情况处理：玩家与目标位置完全重合
    if dx == 0 and dy == 0 and dz == 0:
        cx = screen_size[0] / 2
        cy = screen_size[1] / 2
        return cx, cy, 0.0, True

    # 2. 摄像机旋转角标准化对齐
    # 修正原始 Yaw 的 180 度偏差并取反，确保 0 度指向世界坐标 Z 轴
    cam_yaw = _normalize_angle(-camera_yaw - 180.0)
    cam_pitch = -camera_pitch

    # 3. 计算目标在世界空间中的绝对角度
    horizontal_dist = sqrt(dx * dx + dz * dz)
    target_yaw = degrees(atan2(dx, dz))        # 目标的水平方位角
    target_pitch = degrees(atan2(dy, horizontal_dist))  # 目标的垂直俯仰角

    # 4. 计算玩家视角与目标的相对角度差
    yaw_diff = _normalize_angle(target_yaw - cam_yaw)
    pitch_diff = target_pitch - cam_pitch

    # -------------------------
    # 余弦感度补偿 (Cosine Sensitivity Compensation)
    # -------------------------
    # 修复原理：在球坐标系中，当俯仰角接近正上方或正下方（+/- 90度）时，
    # 经度（Yaw）的微小波动在屏幕上对应的水平距离会急剧放大，导致图标剧烈跳变。
    # 这里的修复通过乘以仰角的余弦值，在极点处平滑压缩水平偏移量，
    # 确保图标在经过玩家头顶/脚底时，能平滑地保持在屏幕垂直中线上。
    cos_factor = abs(cos(radians(target_pitch)))

    # 5. UI 布局参数准备
    cx = screen_size[0] / 2
    cy = screen_size[1] / 2
    icon_half = 10
    # 设定图标在准心周围摆动的引导半径
    radius = min(cx - icon_half, cy - icon_half) - 30

    # 6. 角度映射至屏幕偏移量
    yaw_scale = radius / 45.0
    pitch_scale = radius / 30.0

    # 应用核心修复后的偏移量：控制图标在屏幕上的位置
    offset_x = -yaw_diff * yaw_scale * cos_factor
    offset_y = -pitch_diff * pitch_scale

    # 旋转参考向量：同样应用修复因子，确保箭头在极点处指向稳定
    rot_x = yaw_diff * yaw_scale * cos_factor
    rot_y = -pitch_diff * pitch_scale

    # 7. 判定是否处于准心中心判定区
    in_center = (abs(yaw_diff) * cos_factor <= center_angle and abs(pitch_diff) <= center_angle)

    # 8. 圆形轨道约束 (Radar Ring)
    # 当目标超出视野中心一定距离时，将图标强制限制在设定的圆形轨道上
    dist_sq = offset_x * offset_x + offset_y * offset_y
    radius_sq = radius * radius
    if dist_sq > radius_sq:
        scale = radius / sqrt(dist_sq)
        offset_x *= scale
        offset_y *= scale

    # 9. 最终像素位置计算
    # 针对 14x14 图标采用左上角对齐，减去半径 7 以实现中心点对齐
    # 使用 round() 提供比 int() 更精准的像素位置，防止图标位移抖动
    screen_x = round(cx + offset_x - 7)
    screen_y = round(cy + offset_y - 7)

    # 边缘硬性拦截，防止图标移出屏幕显示区域
    screen_x = max(edge_left, min(screen_x, screen_size[0] - edge_right))
    screen_y = max(edge_top, min(screen_y, screen_size[1] - edge_bottom))

    # 10. 箭头旋转角度计算
    if rot_x == 0 and rot_y == 0:
        rotate_angle = 0.0
    else:
        # 基于补偿后的二维向量计算旋转角，确保箭头始终咬住目标方位
        # +90 度用于将数学上的 atan2 结果对齐到 UI 向上为 0 度的规范
        rotate_angle = degrees(atan2(rot_y, rot_x)) + 90.0

    return screen_x, screen_y, _normalize_angle(rotate_angle), in_center