
# -*- coding: utf-8 -*-

from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi
import miao_Config as CG


@Mod.Binding(name=CG.C_Name, version="0.0.1")
class custom_warehouseMOD(object):

    def __init__(self):
            pass
                
    @Mod.InitServer()
    def custom_warehouseServerInit(self):
        serverApi.RegisterSystem(CG.Mod_Name, CG.S_Name, CG.S_Path)
                    
    @Mod.DestroyServer()
    def custom_warehouseServerDestroy(self):
        pass
                    
    @Mod.InitClient()
    def custom_warehouseClientInit(self):
        clientApi.RegisterSystem(CG.Mod_Name, CG.C_Name, CG.C_Path)
                    
    @Mod.DestroyClient()
    def custom_warehouseClientDestroy(self):
        pass
