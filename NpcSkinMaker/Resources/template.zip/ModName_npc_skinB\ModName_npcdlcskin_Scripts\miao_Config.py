# -*- coding: utf-8 -*-
Mod_Name = __file__.rsplit('/' if '/' in __file__ else '.', 2)[-2]
C_Name = Mod_Name + "ClientSystem"
C_Path = Mod_Name + ".init_modnpcskinClientSystem.init_modnpcskinClientSystem"

S_Name = Mod_Name + "ServerSystem"
S_Path = Mod_Name + ".init_modnpcskinServerSystem.init_modnpcskinServerSystem"
