# -*- coding: utf-8 -*-

import mod.client.extraClientApi as clientApi
import miao_lid as M
import miao_Config as CG

ClientSystem = clientApi.GetClientSystemCls()
CF = clientApi.GetEngineCompFactory()
LevelID = clientApi.GetLevelId()
ME = clientApi.GetMinecraftEnum()


class init_modnpcmodelsClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(init_modnpcmodelsClientSystem, self).__init__(namespace, systemName)
        # 自定义NPC的联动情况
        self.CustomNpcClass = None
        self.ListenEvents()

    def ListenEvents(self):
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), "LoadClientAddonScriptsAfter", self, self.LoadClientAddonScriptsAfter, 10)

    def LoadClientAddonScriptsAfter(self, args):
        self.CustomNpcClass = clientApi.GetSystem('customNPC', 'customNPCClientSystem')
        if self.CustomNpcClass:
            self.CustomNpcClass.NpcDlcModelsConfigNameList.add('ModName_modelsdlc.json')

