# -*- coding: utf-8 -*-

import mod.server.extraServerApi as serverApi
import miao_lid as M
import miao_Config as CG

ServerSystem = serverApi.GetServerSystemCls()
CF = serverApi.GetEngineCompFactory()
LevelID = serverApi.GetLevelId()
ME = serverApi.GetMinecraftEnum()


class init_modnpcmodelsServerSystem(ServerSystem):
    def __init__(self, namespace, systemName):
        ServerSystem.__init__(self, namespace, systemName)