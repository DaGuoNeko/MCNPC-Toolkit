# coding=utf-8
# 版本 1.10
# 大果喵专属复用轮子以及算法。
import time
import math
import re
import random
import datetime
from types import MethodType


class Simulator:

    def __init__(self, crit):
        self.crit = float(crit)
        self.pity_limit = math.ceil(PRD_C(self.crit)[1])  # 保底次数
        self.pity_counter = 0  # 未成功次数

    def start(self):
        self.pity_counter += 1

        if self.pity_counter >= self.pity_limit:
            return self.probability(self.pity_counter * PRD_C(self.crit)[0])
        else:
            return self.probability(PRD_C(self.crit)[0])

    def _return(self):
        self.pity_counter = 0
        return True

    def probability(self, gl):
        if random.random() < gl:  # 5 星概率暂设为 1%
            return self._return()
        else:
            return False


# ------------------------------------------------------------------------- 网易 Minecraft ----------------------------------------------------------------------------------------
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi

CF = serverApi.GetEngineCompFactory()
CCF = clientApi.GetEngineCompFactory()
leveld = serverApi.GetLevelId()


def GetBlockSpawnEntity(pos=(0, 0, 0), y=2, dia=0, defapos=(0, -100, 0)):
    """获取某坐标是否能生成实体，参数: 坐标，y高度， 维度, 默认出生坐标 返回: 空时返回None，否则返回能生成的坐标"""
    trueblocklist = []
    trueblockposlist = []
    for trblock in [(pos[0], pos[1] + ints, pos[2]) for ints in xrange(y)]:
        compinfo = CF.CreateBlockInfo(leveld)
        blockinfo = compinfo.GetBlockNew(trblock, dia)
        if blockinfo and not compinfo.GetBlockBasicInfo(blockinfo['name']).get('solid', True):
            trueblocklist.append(True)
            trueblockposlist.append(trblock)
        else:
            trueblocklist.append(False)
            trueblockposlist.append(trblock)
    truepos = find_consecutive_duplicates(trueblocklist, 2, True)
    if truepos:
        return trueblockposlist[min(truepos)]
    return


def GetEditStateInt(args={}, noneint='0'):
    """文本框变化—整数"""
    a = args['Text']
    try:
        try:
            if a == '':  # 空的就设置为空
                a = ''
            else:
                int(a)  # 判断是否是数字这里是核心部分
                a = a
        except:
            pass
        if args.get('Mode', '') == 'Finished':  # 解决空问题
            if a == '':
                a = noneint
    except:
        return
    return a


def GetEditContInt(Ints='0', MaxInt='10000000000', MinInt='0'):
    """文本框内容—整数"""
    b = Ints
    try:
        if int(float(b)) > int(float(MaxInt)):  # 限制最大数
            b = MaxInt
        elif int(float(b)) < int(float(MinInt)):  # 限制最小数
            b = MinInt
    except:
        return
    return str(int(float(b)))


def GetEditStateFloat(args={}, noneint='0.1'):
    """文本框变化—浮点数"""
    a = args['Text']
    try:
        try:
            if a == '':  # 空的就设置为空
                a = ''
            else:
                int(a)  # 判断是否是数字这里是核心部分
                a = a
        except:
            pass
        if args['Mode'] == 'Finished':  # 解决空问题
            if a == '':
                a = noneint
    except:
        return
    return a


def GetEditContFloat(Ints='0', MaxInt='10000000000.0', MinInt='0.0'):
    """文本框内容—浮点数"""
    b = Ints
    try:
        if float(b) > float(MaxInt):  # 限制最大数
            b = MaxInt
        elif float(b) < float(MinInt):  # 限制最小数
            b = MinInt
    except:
        return
    return b


def NewItem(itemdata):
    """获取优化后的物品"""
    if itemdata:
        newitemdata = {
            'count': itemdata.get('count', 0),
            'newItemName': itemdata.get('newItemName', 'air'),
            'newAuxValue': itemdata.get('newAuxValue', 0),
            'showInHand': itemdata.get('showInHand', True),
            'userData': itemdata.get('userData', {})
        }
        return newitemdata
    else:
        return itemdata


def GetItemisName(itemdata):
    """获取物品名字"""
    name = ''
    if itemdata and itemdata.get("userData", None) and itemdata['userData'].get('display', None) and itemdata['userData']['display'].get('Name', None):
        name = itemdata['userData']['display']['Name']['__value__']
    return name


def GetItemsDurability(itemDict, system=False):
    """获取物品耐久"""
    if system:
        itemComp = CF.CreateItem(clientApi.GetLevelId())
        basicInfo = itemComp.GetItemBasicInfo(itemDict.get('newItemName', ''), itemDict.get('newAuxValue', 0))
    else:
        itemComp = CCF.CreateItem(clientApi.GetLevelId())
        basicInfo = itemComp.GetItemBasicInfo(itemDict.get('newItemName', ''), itemDict.get('newAuxValue', 0))
    if basicInfo:
        maxDurability = basicInfo.get('maxDurability', 0)
        maxDurability = itemDict.get('ModMaxDamage', maxDurability)
        durability = itemDict.get('durability', maxDurability)
        try:
            if itemDict.get('userData', None):
                if itemDict['userData'].get('ModMaxDamage', None):
                    if itemDict['userData'].get('ModMaxDamage', {}).get('__value__', None):
                        maxDurability = itemDict['userData'].get('ModMaxDamage', {}).get('__value__', maxDurability)
                    else:
                        maxDurability = itemDict['userData'].get('ModMaxDamage', maxDurability)
                if itemDict['userData'].get('Damage', None):
                    if str(itemDict['userData'].get('Damage', {}).get('__value__', '')):
                        durability = maxDurability - itemDict['userData'].get('Damage', {}).get('__value__', durability)
                    else:
                        durability = maxDurability - itemDict['userData'].get('Damage', durability)
        except:
            pass
        return durability, maxDurability
    return 0, 0


def GetItemisEnchant(item):
    """获取物品是否附魔"""
    isEnchant = False
    # print item
    try:
        if item.get("enchantData"):
            isEnchant = True
        if item.get("userData"):
            if item.get("userData").get('ench'):
                isEnchant = True
        return isEnchant
    except:
        return isEnchant


def fairDictExc(exckey, dict1, dict2):
    """ 去某键，然后比较俩个字典是否一样"""
    try:
        dict1.pop(exckey, None)
        dict2.pop(exckey, None)
        if dict1 == dict2:
            return True
        else:
            return False
    except:
        return False


def fairdicitems(dict1, dict2):
    """判断是否为同一item，只有itemName和auxValue均相同才返回True"""
    if not dict1 or not dict2:
        return False
    if dict1.get("newItemName", "item1") != dict2.get("newItemName", "item2"):
        return False
    if dict1.get("newAuxValue") != dict2.get("newAuxValue"):
        return False
    if dict1.get("userData") != dict2.get("userData"):
        return False
    if dict1.get("durability") != dict2.get("durability"):
        return False
    return True


def getitemCnStr(items, system=False):
    """获取物品的中文名字, true为在客户端获取，反之服务端"""
    if system:
        itemStr = CCF.CreateItem(clientApi.GetLevelId()).GetItemBasicInfo(items.get('newItemName', 'air'), items.get('newAuxValue', 'air'))['itemName']
    else:
        itemStr = CF.CreateItem(serverApi.GetLevelId()).GetItemBasicInfo(items.get('newItemName', 'air'), items.get('newAuxValue', 0))['itemName']
    names = GetItemisName(items)
    if GetItemisName(items) == '':
        return itemStr
    else:
        return names


def GetEntityName(entityid, system=False):
    """获取实体的中文名字, true为在客户端获取，反之服务端"""
    Name = '未知'
    if system:
        compname = CCF.CreateName(entityid)
        compgame = CCF.CreateGame(clientApi.GetLevelId())
        compstr = CCF.CreateEngineType(entityid)
    else:
        compname = CF.CreateName(entityid)
        compgame = CF.CreateGame(serverApi.GetLevelId())
        compstr = CF.CreateEngineType(entityid)
    _str = compstr.GetEngineTypeStr()
    _name = compname.GetName()
    try:
        if _name:
            Name = _name
        else:
            _d = compgame.GetChinese("entity.{}.name".format(_str.split(':')[1]))
            Name = Name if _d.count('entity.') else _d
    except:
        pass
    return Name


# ------------------------------------------------------------------------- 其他 ----------------------------------------------------------------------------------------

def sort_list(lst, reverse=False):
    """
    对列表进行字母或数字的排序，支持中文和数字排序，并可以选择升序或降序。

    参数:
        lst (list): 待排序的列表
        reverse (bool): 如果为True，列表将按降序排序；默认False（升序）

    返回:
        list: 排序后的列表
    """
    return sorted(lst, key=lambda x: str(x), reverse=reverse)


def is_integer(s):
    # type: (str) -> bool
    """检查是否是数字，并且是否是整数"""
    try:
        int(s)
        return True
    except:
        return False


def is_float(s):
    # type: (str) -> bool
    """检查是否是数字，并且是否是浮点数"""
    try:
        float(s)
        return True
    except:
        return False


def minecraft_is_value_in_range(range_str, value):
    # type: (str, float) -> bool
    """模拟指令中的..15,1..5查询某数值在某范围内，返回bool"""
    if '..' in range_str:
        # 分割范围字符串为起始和结束值
        start, end = range_str.split('..')

        # 处理起始值和结束值
        start = float(start) if start else None
        end = float(end) if end else None

        # 检查值是否在范围内
        if start is not None and end is not None:
            return start <= value <= end
        elif start is None:
            return value <= end
        elif end is None:
            return value >= start
    else:
        # 如果范围字符串没有'..'，直接比较值
        return float(range_str) == value
    return False


def GetDataDefDefault(data, defaultvalue=None):
    """获取数据，数据为空的时候返回给予的默认值"""
    if data:
        return data
    else:
        return defaultvalue


def CreateDynamicBind(ui, function, tag=""):
    # type: (any, any, str) -> None
    '''
    给UI系统动态创建绑定\n
    注意, CreateUI创建的界面, 在Create函数中, 调用此接口绑定无效\n
    PushScreen的界面, Create中调用有效\n
    ui: UI系统实例
    function: 给UI创建此方法
    tag: 在方法名尾部追加此标签
    '''
    function.__name__ = function.__name__ + "_" + tag
    setattr(ui, function.__name__, MethodType(function, ui))


def get_to_zero(num, tolerance=1e-15):
    """判断一个数是否无限接近0，是则返回0.0， 否则返回原数"""
    if abs(num) < tolerance:
        return 0.0
    else:
        return num


def sort_dict_by_key(d, k):
    """按照字典的某个键的值进行排序，返回一个列表"""
    items = list(d.items())
    print items
    items.sort(key=lambda item: item[1][k])
    return items


def check_coordinate_in_rectangle(coord, point_a, point_b):
    """检测某坐标是否在ab点坐标范围内,参数: 待检测的坐标，a点坐标，b点坐标  返回: bool"""
    x, y, z = coord
    min_x, max_x, min_y, max_y, min_z, max_z = min(point_a[0], point_b[0]), max(point_a[0], point_b[0]), min(point_a[1], point_b[1]), max(point_a[1], point_b[1]), min(point_a[2], point_b[2]), max(point_a[2], point_b[2])
    if min_x <= x <= max_x and min_y <= y <= max_y and min_z <= z <= max_z:
        return True
    else:
        return False


def find_consecutive_duplicates(lst, num, target):
    """根据参数搜索列表相同相邻的的元素索引位置,参数: 列表，几个相同，找什么元素  返回: 列表"""
    result = []
    length = len(lst)
    for i in range(length - num + 1):
        if lst[i:i + num] == [target] * num:
            result.append(i)
    return result


def sort_items_by_keyword(items, keyword, key=''):
    """搜索某列表中指定键的值，返回列表"""
    result = []
    for item in items:
        if key in item and keyword in item[key]:
            result.append(item)
    return result


def timestamp_to_time(timestamp):
    """吧时间戳转换成时间的格式"""
    # 将时间戳转换为datetime对象
    dt_object = datetime.datetime.fromtimestamp(timestamp)
    # 使用strftime函数格式化时间
    formatted_time = dt_object.strftime('%Y-%m-%d %H:%M:%S')
    return formatted_time


def get_timestamp_to_time(_TS=0):
    """根据时间戳获取剩余的时间格式,返回 天， 小时， 分钟"""
    days = _TS // (24 * 3600)
    timestamp = _TS % (24 * 3600)
    hours = timestamp // 3600
    timestamp %= 3600
    minutes = timestamp // 60
    return days, hours, minutes


# 定义一个函数，根据给定的x,y,z坐标，返回一个坐标列表，表示伤害数值的跳动动画
def damage_jump(x, y, z):
    # 定义一个空列表，用来存储坐标
    coords = []
    # 定义一个变量，表示跳动的高度
    height = 0.8
    # 定义一个变量，表示跳动的深度
    depth = 1
    # 定义一个变量，表示跳动的步数
    steps = 30
    # 定义一个变量，表示每一步的垂直位移
    dy = height / steps
    # 定义一个变量，表示每一步的水平位移
    dz = depth / steps
    # 定义一个变量，表示重力加速度
    g = -2 * dy / (steps ** 2)
    # 随机生成一个方向，1表示向前，-1表示向后
    direction = random.choice([1, -1])
    # 使用一个循环，计算每一步的坐标，并添加到列表中
    for i in range(steps):
        # 计算当前步数的x坐标，假设不变
        x_curr = x + direction * i * dz
        # 计算当前步数的y坐标，假设向上为正方向
        y_curr = y + i * dy + g * (i ** 2) / 2
        # 计算当前步数的z坐标，根据方向乘以dz
        z_curr = z
        # 将当前步数的坐标添加到列表中
        coords.append((x_curr, y_curr, z_curr))
    # 返回坐标列表
    return coords


def get_string_type(input_string):
    """获取字符串是数字还是字符串类型"""
    if input_string.isdigit():
        return int
    else:
        return str


def _HSB2RGB(h, s, v):
    """# hsb 转 rgb"""
    if s == 0:
        return v, v, v
    if h >= 360:
        h = 0
    i = int((h / 60.0) % 6)
    f = (h / 60.0) - i
    p = v * (1.0 - s)
    q = v * (1.0 - s * f)
    t = v * (1.0 - s * (1.0 - f))
    if i == 0:
        if t > 1:
            t = 0.0
        return v, t, p
    if i == 1:
        return q, v, p
    if i == 2:
        return p, v, t
    if i == 3:
        return p, q, v
    if i == 4:
        return t, p, v
    if i == 5:
        return v, p, q


def RGB2HSB(r, g, b):
    """# rgb 转 hsb"""
    r, g, b = r * 255, g * 255, b * 255
    maxs = max(r, g, b)
    mins = min(r, g, b)
    A = maxs - mins
    hsb_B = maxs / 255.0
    hsb_S = 0 if maxs == 0 else A / maxs
    hsb_H = 0
    if A == 0:
        hsb_H = 0
    elif maxs == r and g >= b:
        hsb_H = (g - b) * 60.0 / A + 0
    elif maxs == r and g < b:
        hsb_H = (g - b) * 60.0 / A + 360
    elif maxs == g:
        hsb_H = (b - r) * 60.0 / A + 120
    elif maxs == b:
        hsb_H = (r - g) * 60.0 / A + 240
    return hsb_H, hsb_S, hsb_B


def move_list_index(lst, index, strea):
    """对元素进行下移或上移"""
    if strea:
        if index > 0:
            lst[index], lst[index - 1] = lst[index - 1], lst[index]
    else:
        if index < len(lst) - 1:
            lst[index], lst[index + 1] = lst[index + 1], lst[index]


def get_element(lst, index, default_value):
    """列表索引不到元素时返回一个默认值"""
    try:
        return lst[index]
    except:
        return default_value


def extract_brackets_content(s, exvalue='{}'):
    """ 使用正则表达式匹配大括号内的内容"""
    if exvalue == '{}':
        result = re.findall(r'\{(.*?)\}', s)
    else:
        result = re.findall(r'\((.*?)\)', s)
    return result


def GetABposDac(pos1, pos2):
    """获取A点与B点的距离,需传入A点坐标，和B点坐标"""
    x1 = pos1[0]
    y1 = pos1[1]
    z1 = pos1[2]

    x2 = pos2[0]
    y2 = pos2[1]
    z2 = pos2[2]
    d = math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2 + (z1 - z2) ** 2)
    return d


def GetABPosHub(pos1, pos2):
    """获取A点与B点的中心点坐标,需传入A点坐标，和B点坐标"""
    x1 = pos1[0]
    y1 = pos1[1]
    z1 = pos1[2]
    x2 = pos2[0]
    y2 = pos2[1]
    z2 = pos2[2]
    o1 = (x1 + x2) / 2
    o2 = (y1 + y2) / 2
    o3 = (z1 + z2) / 2
    s = (o1, o2, o3)
    return s


def get_coordinates_within_circle(center, diameter):
    """以A点为中心获取直径圆形内的所有坐标，需传入A点坐标，和直径, 返回列表"""
    coordinates = []
    radius = diameter / 2
    min_x = int(center[0] - radius)
    max_x = int(center[0] + radius)
    min_z = int(center[2] - radius)
    max_z = int(center[2] + radius)

    for x in range(min_x, max_x + 1):
        for y in range(center[1] - int(radius), center[1] + int(radius) + 1):
            for z in range(min_z, max_z + 1):
                if math.sqrt((x - center[0]) ** 2 + (z - center[2]) ** 2) <= radius:
                    coordinates.append((x, y, z))

    return coordinates


def radaoms(ints):
    """概率成功，需传入概率数值"""
    b = random.randint(1, 100)
    if ints >= b:
        return True
    else:
        return False


def floatradaom(floatint):
    """概率成功，需传入概率数值,支持小数点"""
    floats = round(floatint, 1)
    if floats < 1.0:
        if radaoms(1):
            if floats >= random.random():
                return True
        return False
    else:
        return radaoms(int(floats))


def GetBlockPosNew(one, two):
    """新的获取A点与B点形成的立体空间内所有坐标，需传入A点坐标，和B点坐标, 返回列表"""
    if two[0] < 0 and one[0] > two[0] or one[0] > two[0]:
        x_coord = [x for x in range(one[0], two[0] - 1, -1)]
        if two[1] < 0 and one[1] > two[1] or one[1] > two[1]:
            z_coord = [z for z in range(one[1], two[1] - 1, -1)]
            if two[2] < 0 and one[2] > two[2] or one[2] > two[2]:
                y_coord = [y for y in range(one[2], two[2] - 1, -1)]
            else:
                y_coord = [y for y in range(one[2], two[2] + 1)]
            new_coords = [(x, z, y) for x in x_coord for z in z_coord for y in y_coord]
            return new_coords
        else:
            z_coord = [z for z in range(one[1], two[1] + 1)]
            if two[2] < 0 and one[2] > two[2] or one[2] > two[2]:
                y_coord = [y for y in range(one[2], two[2] - 1, -1)]
            else:
                y_coord = [y for y in range(one[2], two[2] + 1)]
            new_coords = [(x, z, y) for x in x_coord for z in z_coord for y in y_coord]
            return new_coords
    else:
        x_coord = [x for x in range(one[0], two[0] + 1)]
        if two[1] < 0 and one[1] > two[1] or one[1] > two[1]:
            z_coord = [z for z in range(one[1], two[1] - 1, -1)]
            if two[2] < 0 and one[2] > two[2] or one[2] > two[2]:
                y_coord = [y for y in range(one[2], two[2] - 1, -1)]
            else:
                y_coord = [y for y in range(one[2], two[2] + 1)]
            new_coords = [(x, z, y) for x in x_coord for z in z_coord for y in y_coord]
            return new_coords
        else:
            z_coord = [z for z in range(one[1], two[1] + 1)]
            if two[2] < 0 and one[2] > two[2] or one[2] > two[2]:
                y_coord = [y for y in range(one[2], two[2] - 1, -1)]
            else:
                y_coord = [y for y in range(one[2], two[2] + 1)]
            new_coords = [(x, z, y) for x in x_coord for z in z_coord for y in y_coord]
            return new_coords


def unicode_convert(input):
    """'去掉带u的字典,需传入带u的字典"""
    if isinstance(input, dict):
        return {unicode_convert(key): unicode_convert(value) for key, value in input.iteritems()}
    elif isinstance(input, list):
        return [unicode_convert(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input


def get_relative_coordinates(startpos, apos, bpos):
    """根据起点坐标获取ab点坐标之间所有方块的相对坐标列表，参数 起点坐标，a点坐标，b点坐标"""
    relative_coordinates = []
    for x in range(apos[0], bpos[0] + 1):
        for y in range(apos[1], bpos[1] + 1):
            for z in range(apos[2], bpos[2] + 1):
                relative_coordinates.append((x - startpos[0], y - startpos[1], z - startpos[2]))
    return relative_coordinates


def PRD_C(Chance):
    _C = {
        '0.01': [0.000156, 6411], '0.02': [0.00062, 1613], '0.03': [0.001386, 722], '0.04': [0.002449, 409], '0.05': [0.003802, 264], '0.06': [0.00544, 184], '0.07': [0.007359, 136], '0.08': [0.009552, 105], '0.09': [0.012016, 84],
        '0.1': [0.014746, 68], '0.11': [0.017736, 57], '0.12': [0.020983, 48], '0.13': [0.024482, 41], '0.14': [0.02823, 36], '0.15': [0.032221, 32], '0.16': [0.036452, 28], '0.17': [0.04092, 25], '0.18': [0.04562, 22],
        '0.19': [0.050549, 20], '0.2': [0.055704, 18], '0.21': [0.061081, 17], '0.22': [0.066676, 15], '0.23': [0.072488, 14], '0.24': [0.078511, 13], '0.25': [0.084744, 12], '0.26': [0.091183, 11], '0.27': [0.097826, 11],
        '0.28': [0.10467, 10], '0.29': [0.111712, 9], '0.3': [0.118949, 9], '0.31': [0.126379, 8], '0.32': [0.134001, 8], '0.33': [0.141805, 8], '0.34': [0.14981, 7], '0.35': [0.157983, 7], '0.36': [0.166329, 7], '0.37': [0.174909, 6], '0.38': [0.183625, 6], '0.39': [0.192486, 6],
        '0.4': [0.201547, 5], '0.41': [0.21092, 5], '0.42': [0.220365, 5], '0.43': [0.229899, 5], '0.44': [0.23954, 5], '0.45': [0.249307, 5], '0.46': [0.259872, 4], '0.47': [0.270453, 4], '0.48': [0.281008, 4],
        '0.49': [0.291552, 4], '0.5': [0.302103, 4], '0.51': [0.312677, 4], '0.52': [0.323291, 4], '0.53': [0.33412, 3], '0.54': [0.34737, 3], '0.55': [0.360398, 3], '0.56': [0.3732173, 3], '0.57': [0.38584, 3], '0.58': [0.398278, 3], '0.59': [0.410545, 3], '0.6': [0.42265, 3],
        '0.61': [0.434604, 3], '0.62': [0.446419, 3], '0.63': [0.458104, 3], '0.64': [0.46967, 3], '0.65': [0.481125, 3], '0.66': [0.492481, 3], '0.67': [0.507463, 2], '0.68': [0.529412, 2], '0.69': [0.550725, 2],
        '0.7': [0.571429, 2], '0.71': [0.591549, 2], '0.72': [0.611111, 2], '0.73': [0.630137, 2], '0.74': [0.648649, 2], '0.75': [0.666667, 2], '0.76': [0.684211, 2], '0.77': [0.701299, 2], '0.78': [0.717949, 2],
        '0.79': [0.734177, 2], '0.8': [0.75, 2], '0.81': [0.765432, 2], '0.82': [0.780488, 2], '0.83': [0.795181, 2], '0.84': [0.809524, 2], '0.85': [0.823529, 2], '0.86': [0.837209, 2], '0.87': [0.850575, 2],
        '0.88': [0.863636, 2], '0.89': [0.876404, 2], '0.9': [0.888889, 2], '0.91': [0.901099, 2], '0.92': [0.913043, 2], '0.93': [0.924731, 2], '0.94': [0.93617, 2], '0.95': [0.947368, 2], '0.96': [0.958333, 2], '0.97': [0.969072, 2],
        '0.98': [0.979592, 2], '0.99': [0.989899, 2], '1.0': [1.0, 1]
    }
    return _C[str(round(Chance / 100, 2))]
