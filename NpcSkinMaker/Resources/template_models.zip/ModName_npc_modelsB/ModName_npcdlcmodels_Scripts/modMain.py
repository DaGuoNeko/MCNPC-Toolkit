# -*- coding: utf-8 -*-

from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi
import miao_Config as CG


@Mod.Binding(name=CG.C_Name, version="0.0.1")
class init_modnpcMOD(object):
    def __init__(self):
        pass

    @Mod.InitServer()
    def init_modnpcServerInit(self):
        serverApi.RegisterSystem(CG.Mod_Name, CG.S_Name, CG.S_Path)

    @Mod.DestroyServer()
    def init_modnpcServerDestroy(self):
        pass

    @Mod.InitClient()
    def init_modnpcClientInit(self):
        clientApi.RegisterSystem(CG.Mod_Name, CG.C_Name, CG.C_Path)

    @Mod.DestroyClient()
    def init_modnpcClientDestroy(self):
        pass